plugins {
    id("com.android.application") version "8.5.2" apply false  // ← غير إلى 8.5.2
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}

tasks.register("clean", Delete::class) {
    delete(rootProject.buildDir)
}