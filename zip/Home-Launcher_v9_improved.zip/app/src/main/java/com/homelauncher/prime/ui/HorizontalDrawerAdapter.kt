package com.homelauncher.prime.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.homelauncher.prime.R
import com.homelauncher.prime.data.AppItem

/**
 * Horizontal pager: splits drawer entries into pages of (rows*cols) and renders
 * each page as a small grid using DrawerCellAdapter.
 *
 * Pages are FINITE: exactly `realPageCount` pages. Swiping past either end stops.
 */
class HorizontalDrawerAdapter(
    private val entries: List<DrawerEntry>,
    private val cols: Int,
    private val rows: Int,
    private val onAppClick: (AppItem, View) -> Unit,
    private val onAppLongClick: (AppItem, View) -> Unit,
    private val onFolderLongClick: (String, View) -> Unit,
    private val selection: DrawerCellAdapter.SelectionState? = null,
    private val cyclicMode: Boolean = false
) : RecyclerView.Adapter<HorizontalDrawerAdapter.PageVH>() {

    private val perPage = (cols * rows).coerceAtLeast(1)

    // Process-wide pool: keeps cells warm even when switching Personal/Work adapters.
    private val sharedPool = GLOBAL_POOL

    /** Number of *real* (distinct) pages. */
    val realPageCount: Int
        get() = if (entries.isEmpty()) 1 else (entries.size + perPage - 1) / perPage

    /** Cyclic paging is opt-in via preference. */
    val cyclic: Boolean get() = cyclicMode && realPageCount > 1

    private val virtualCount: Int get() = if (cyclic) CYCLIC_COUNT else realPageCount

    /** Start at virtual middle aligned to real index 0 in cyclic mode. */
    fun startPosition(): Int =
        if (cyclic) (CYCLIC_COUNT / 2).let { it - (it % realPageCount) } else 0

    /** Convert a virtual position into a 0-based real index. */
    fun realIndex(virtualPos: Int): Int =
        if (cyclic) ((virtualPos % realPageCount) + realPageCount) % realPageCount
        else virtualPos.coerceIn(0, (realPageCount - 1).coerceAtLeast(0))

    private val iconDp: Int = when {
        cols >= 9 -> 28
        cols >= 7 -> 32
        cols >= 6 -> 40
        cols >= 5 -> 48
        else -> 56
    }

    class PageVH(v: View) : RecyclerView.ViewHolder(v) {
        val grid: RecyclerView = v.findViewById(R.id.pageGrid)
        var helperAttached: Boolean = false
    }

    override fun getItemCount(): Int = virtualCount

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.page_drawer, parent, false)
        val vh = PageVH(v)
        vh.grid.setHasFixedSize(true)
        vh.grid.layoutManager = FillingGridLayoutManager(parent.context, cols, rows)
        vh.grid.setRecycledViewPool(sharedPool)
        vh.grid.isNestedScrollingEnabled = false
        // Allow long-press drag to reorder icons within this page.
        if (!vh.helperAttached) {
            val cb = object : ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP or ItemTouchHelper.DOWN or
                ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
            ) {
                override fun isLongPressDragEnabled(): Boolean = false
                override fun onMove(
                    rv: RecyclerView,
                    src: RecyclerView.ViewHolder,
                    target: RecyclerView.ViewHolder
                ): Boolean {
                    val a = rv.adapter as? DrawerCellAdapter ?: return false
                    a.moveItem(src.bindingAdapterPosition, target.bindingAdapterPosition)
                    return true
                }
                override fun onSwiped(vh2: RecyclerView.ViewHolder, dir: Int) {}
            }
            ItemTouchHelper(cb).attachToRecyclerView(vh.grid)
            vh.helperAttached = true
        }
        return vh
    }

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        val real = realIndex(position)
        val from = real * perPage
        val to = minOf(entries.size, from + perPage)
        val slice = if (from >= entries.size) emptyList() else entries.subList(from, to)
        val existing = holder.grid.adapter as? DrawerCellAdapter
        if (existing == null) {
            holder.grid.adapter = DrawerCellAdapter(
                slice.toMutableList(), iconDp,
                onAppClick, onAppLongClick, onFolderLongClick, selection
            )
        } else {
            existing.submit(slice)
        }
    }

    companion object {
        // A large but safe virtual count (~1M pages). Plenty for any user lifetime.
        private const val CYCLIC_COUNT = 1_000_000
        private val GLOBAL_POOL = RecyclerView.RecycledViewPool().apply {
            setMaxRecycledViews(0, 48) // apps
            setMaxRecycledViews(1, 24) // folders
        }
    }
}
