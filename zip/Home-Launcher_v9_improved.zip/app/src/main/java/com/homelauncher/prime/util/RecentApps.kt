package com.homelauncher.prime.util

import android.content.Context
import androidx.preference.PreferenceManager

/** Tracks the last N packages the user launched from the launcher. */
object RecentApps {
    private const val KEY = "recent_apps_list"
    private const val MAX = 12

    fun record(ctx: Context, appId: String) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(ctx)
        val raw = prefs.getString(KEY, "") ?: ""
        val cur = raw.split('|').filter { it.isNotBlank() }.toMutableList()
        cur.remove(appId)
        cur.add(0, appId)
        while (cur.size > MAX) cur.removeAt(cur.size - 1)
        prefs.edit().putString(KEY, cur.joinToString("|")).apply()
    }

    fun get(ctx: Context): List<String> {
        val prefs = PreferenceManager.getDefaultSharedPreferences(ctx)
        val raw = prefs.getString(KEY, "") ?: ""
        return raw.split('|').filter { it.isNotBlank() }
    }
}
