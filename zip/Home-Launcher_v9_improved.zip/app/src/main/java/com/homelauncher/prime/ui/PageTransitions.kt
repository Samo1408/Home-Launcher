package com.homelauncher.prime.ui

import android.view.View
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs

/**
 * All transformers are non-overlapping by construction:
 *  - translationX = -position * width  (pages align edge-to-edge, never stack)
 *  - alpha = 0 at |position| >= 1  (outgoing page is fully invisible before next arrives)
 *  - scale/rotate effects only apply within [-1, 1]
 */
object PageTransitions {

    fun get(name: String): ViewPager2.PageTransformer = when (name) {
        "bounce" -> BounceTransformer()
        "flip" -> FlipTransformer()
        "zoom_in" -> ZoomInTransformer()
        "zoom_out" -> ZoomOutTransformer()
        "fade_in" -> FadeInTransformer()
        "fade_out" -> FadeOutTransformer()
        "big_to_small" -> BigToSmallTransformer()
        "small_to_big" -> SmallToBigTransformer()
        "scroll" -> SlideTransformer()
        "rotate" -> RotateTransformer()
        "none" -> ViewPager2.PageTransformer { _, _ -> }
        else -> SlideTransformer()
    }

    abstract class BaseTransformer : ViewPager2.PageTransformer {
        override fun transformPage(page: View, position: Float) {
            // Force clipping so nothing bleeds outside the page bounds during transitions
            (page.parent as? android.view.ViewGroup)?.clipChildren = true
            page.clipToOutline = false
            page.translationX = -position * page.width
            page.translationY = 0f
            if (position <= -1f || position >= 1f) {
                page.alpha = 0f
                page.scaleX = 1f; page.scaleY = 1f
                page.rotation = 0f; page.rotationY = 0f; page.rotationX = 0f
                return
            }
            onTransform(page, position)
        }
        abstract fun onTransform(page: View, position: Float)
    }

    class SlideTransformer : BaseTransformer() {
        override fun onTransform(page: View, position: Float) {
            page.alpha = 1f; page.scaleX = 1f; page.scaleY = 1f
            page.rotation = 0f; page.rotationY = 0f
        }
    }

    class BounceTransformer : BaseTransformer() {
        override fun onTransform(page: View, position: Float) {
            val s = 1f - abs(position) * 0.12f
            page.scaleX = s; page.scaleY = s
            page.alpha = 1f - abs(position)          // fully gone at |1|
        }
    }

    class FlipTransformer : BaseTransformer() {
        override fun onTransform(page: View, position: Float) {
            page.alpha = if (abs(position) > 0.5f) 0f else 1f - abs(position) * 2f * 0f + 1f
            page.pivotX = if (position < 0) page.width.toFloat() else 0f
            page.pivotY = page.height * 0.5f
            page.rotationY = 90f * position
            page.scaleX = 1f; page.scaleY = 1f
        }
    }

    /** Incoming zooms in from small → 1; outgoing scales down and fades to 0. */
    class ZoomInTransformer : BaseTransformer() {
        override fun onTransform(page: View, position: Float) {
            val scale = (1f - abs(position) * 0.4f).coerceAtLeast(0.6f)
            page.scaleX = scale; page.scaleY = scale
            page.alpha = 1f - abs(position)          // fully gone at |1|
        }
    }

    /** Outgoing zooms out & fades to 0; incoming stays at scale 1. */
    class ZoomOutTransformer : BaseTransformer() {
        override fun onTransform(page: View, position: Float) {
            if (position <= 0f) {
                // Outgoing (moving off to the left)
                val scale = (1f + position * 0.3f).coerceAtLeast(0.7f) // shrinks
                page.scaleX = scale; page.scaleY = scale
                page.alpha = 1f - abs(position)
            } else {
                // Incoming (from the right)
                page.scaleX = 1f; page.scaleY = 1f
                page.alpha = 1f - abs(position)
            }
        }
    }

    class FadeInTransformer : BaseTransformer() {
        override fun onTransform(page: View, position: Float) {
            page.alpha = 1f - abs(position)
            page.scaleX = 1f; page.scaleY = 1f
        }
    }

    class FadeOutTransformer : BaseTransformer() {
        override fun onTransform(page: View, position: Float) {
            page.alpha = 1f - abs(position)
            val s = 1f - abs(position) * 0.08f
            page.scaleX = s; page.scaleY = s
        }
    }

    class BigToSmallTransformer : BaseTransformer() {
        override fun onTransform(page: View, position: Float) {
            val scale = (1f - abs(position) * 0.3f).coerceAtLeast(0.7f)
            page.scaleX = scale; page.scaleY = scale
            page.alpha = 1f - abs(position)
        }
    }

    class SmallToBigTransformer : BaseTransformer() {
        override fun onTransform(page: View, position: Float) {
            val scale = (0.8f + (1f - abs(position)) * 0.2f).coerceIn(0.8f, 1f)
            page.scaleX = scale; page.scaleY = scale
            page.alpha = 1f - abs(position)
        }
    }

    class RotateTransformer : BaseTransformer() {
        override fun onTransform(page: View, position: Float) {
            page.rotation = 10f * position
            page.pivotX = page.width * 0.5f
            page.pivotY = page.height.toFloat()
            page.alpha = 1f - abs(position)
            val s = 1f - abs(position) * 0.06f
            page.scaleX = s; page.scaleY = s
        }
    }
}
