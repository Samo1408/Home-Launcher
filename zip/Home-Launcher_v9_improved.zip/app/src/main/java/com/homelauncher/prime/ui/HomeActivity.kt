package com.homelauncher.prime.ui

import android.app.admin.DevicePolicyManager
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.net.TrafficStats
import android.os.Handler
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Locale

import android.os.Looper
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.homelauncher.prime.R
import com.homelauncher.prime.data.AppItem
import com.homelauncher.prime.data.AppRepository
import com.homelauncher.prime.util.DesktopStore
import com.homelauncher.prime.util.IconCache
import com.homelauncher.prime.util.IntentUtil
import com.homelauncher.prime.util.RootUtil
import com.homelauncher.prime.ui.DrawerCellAdapter.SelectionState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class HomeActivity : AppCompatActivity() {

    // Desktop: multi-page ViewPager2 replacing the old RecyclerView
    private lateinit var desktopPager: ViewPager2
    private lateinit var desktopPageIndicator: TextView
    private lateinit var drawerPager: ViewPager2
    private lateinit var drawerVertical: RecyclerView

    private lateinit var widgetClock: TextView
    private lateinit var widgetDate: TextView
    private lateinit var widgetIp: TextView
    private lateinit var btnSettings: android.widget.ImageButton
    private lateinit var widgetSpeed: TextView
    private var netMonitorHandler: Handler? = null
    private var netMonitorRunnable: Runnable? = null
    private var lastRxBytes: Long = 0
    private var lastTxBytes: Long = 0
    private var lastNetTime: Long = 0
    private lateinit var widgetArea: View
    private lateinit var widgetHostContainer: LinearLayout
    private lateinit var dockRecents: RecyclerView
    private var lastNonDesktopPage: Int = -1  // last selected desktop page (> 0) for "last" action
    private var lastDrawerWasOpen: Boolean = false   // did drawer show when home was pressed (last action)
    private var lastDrawerWorkTab: Boolean = false   // which work tab was active when drawer was open
    private lateinit var drawer: View
    private lateinit var drawerHeader: View
    private lateinit var openDrawer: View
    private lateinit var closeDrawer: ImageButton
    private lateinit var sortDrawer: ImageButton
    private lateinit var refreshDrawer: ImageButton
    private lateinit var settingsBtn: ImageButton
    private lateinit var tabPersonal: View
    private lateinit var tabWork: View
    private lateinit var rootView: View
    private lateinit var homeContent: View

    private var apps: List<AppItem> = emptyList()
    private var currentWorkTab = false
    // Multi-page state
    private var desktopPages: MutableList<MutableList<DesktopAdapter.Entry>> = mutableListOf()
    private var currentDesktopPage: Int = 0
    private var desktopDragging: Boolean = false // suppress drawer gestures during drag

    private lateinit var homeDetector: GestureDetector
    private lateinit var drawerDetector: GestureDetector
    private lateinit var widgetHost: WidgetHostManager
    private val selection = DrawerCellAdapter.SelectionState()
    private lateinit var swipeUpHandle: View
    private lateinit var selectionBar: View
    private lateinit var selectionCount: TextView
    private lateinit var drawerSearch: EditText
    private var searchQuery: String = ""
    private var drawerVerticalTouchHelper: ItemTouchHelper? = null

    private var dragProgress: Float = 0f
    private var dragStartProgress: Float = 0f
    private var dragStartY: Float = 0f
    private var dragStartX: Float = 0f
    private var dragActivated: Boolean = false
    private var dragCandidate: Int = 0
    private var dragAnimator: ValueAnimator? = null
    private val touchSlop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    private val lpHandler = Handler(Looper.getMainLooper())
    private var lpRunnable: Runnable? = null
    private var lpDownX: Float = 0f
    private var lpDownY: Float = 0f
    private var lpFired: Boolean = false

    private fun prefs() = PreferenceManager.getDefaultSharedPreferences(this)
    private fun gestureSensitivity(): Int = prefs().getInt("gesture_sensitivity", 50).coerceIn(0, 100)
    private fun drawerDragSensitivity(): Int = prefs().getInt("drawer_drag_sensitivity", 50).coerceIn(1, 100)
    private fun animationsEnabled(): Boolean = prefs().getBoolean("animations_enabled", true)
    private fun longPressMs(): Long = prefs().getInt("long_press_ms", 500).coerceIn(150, 1200).toLong()
    private fun transitionMs(): Long = prefs().getInt("transition_ms", 260).coerceIn(80, 800).toLong()
    /**
     * Per-direction slop for drawer drag:
     * - Opening the drawer: uses drawerDragSensitivity (1-100) to scale threshold.
     *   At 1 → threshold = 4dp (very easy). At 100 → threshold = 20dp.
     * - Closing the drawer: always 16dp fixed (reliable, never changes with sensitivity).
     */
    private fun drawerOpenSlopPx(): Int {
        val s = drawerDragSensitivity()
        // Map 1-100 to 4-20 dp
        val dp = 4 + (s - 1) * 16 / 99
        return dp(dp.toInt())
    }
    private fun drawerCloseSlopPx(): Int = dp(16)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        AppRepository.registerPackageListener(this)
        // Long-press on empty desktop handled via handleHomeLongPress in dispatchTouchEvent
        try {
            androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
            window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = Color.TRANSPARENT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.isStatusBarContrastEnforced = false; window.isNavigationBarContrastEnforced = false
            }
        } catch (_: Throwable) {}

        rootView = findViewById(R.id.root); homeContent = findViewById(R.id.homeContent)
        desktopPager = findViewById(R.id.desktopPager)
        desktopPageIndicator = findViewById(R.id.desktopPageIndicator)
        drawerPager = findViewById(R.id.drawerPager); drawerVertical = findViewById(R.id.drawerVertical)

        widgetArea = findViewById(R.id.widgetArea); widgetHostContainer = findViewById(R.id.widgetHost)
        dockRecents = findViewById(R.id.dockRecents)
        widgetClock = findViewById(R.id.widgetClock); widgetDate = findViewById(R.id.widgetDate)
        widgetIp = findViewById(R.id.widgetIp); widgetSpeed = findViewById(R.id.widgetSpeed)
        btnSettings = findViewById(R.id.btnSettings); btnSettings.setOnClickListener { startActivity(android.content.Intent(this, SettingsActivity::class.java)) }
        drawer = findViewById(R.id.drawer); drawerHeader = findViewById(R.id.drawerHeader)
        openDrawer = findViewById(R.id.openDrawer)
        closeDrawer = findViewById(R.id.closeDrawer); sortDrawer = findViewById(R.id.sortDrawer)
        refreshDrawer = findViewById(R.id.refreshDrawer); settingsBtn = findViewById(R.id.settingsBtn)
        tabPersonal = findViewById(R.id.tabPersonal); tabWork = findViewById(R.id.tabWork)
        drawerSearch = findViewById(R.id.drawerSearch)

        widgetHost = WidgetHostManager(this, widgetHostContainer)

        ViewCompat.setOnApplyWindowInsetsListener(rootView) { _, insets ->
            val sys = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            homeContent.setPadding(sys.left, sys.top, sys.right, sys.bottom)
            drawerHeader.setPadding(drawerHeader.paddingLeft, sys.top + dp(4), drawerHeader.paddingRight, drawerHeader.paddingBottom)

            desktopPageIndicator.setPadding(dp(12), dp(4), dp(12), dp(2))
            insets
        }
        ViewCompat.requestApplyInsets(rootView)

        homeDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onDoubleTap(e: MotionEvent): Boolean { lockNow(); return true }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y; val dx = e2.x - e1.x
                if (abs(dy) < abs(dx) * 0.4f) return false
                if (dy < -dp(40) && abs(vy) > 500) {
                    if (openMode() == "swipe") { showDrawer(true); return true }
                }
                if (dy > dp(40) && abs(vy) > 500) { expandNotifications(); return true }
                return false
            }
        }).apply { setIsLongpressEnabled(false) }

        drawerDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y; val dx = e2.x - e1.x
                if (dy > dp(50) && abs(vy) > 800 && abs(dy) > abs(dx) * 1.5f) { showDrawer(false); return true }
                return false
            }
        })

        // Swipe-down on header: quick close
        drawerHeader.setOnTouchListener { _, ev -> drawerDetector.onTouchEvent(ev); false }

        drawerSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { searchQuery = s?.toString()?.trim() ?: ""; renderDrawer(currentWorkTab) }
        })

        openDrawer.setOnClickListener { if (!isDesktopMode()) showDrawer(true) }
        closeDrawer.setOnClickListener { if (!isDesktopMode()) showDrawer(false) }
        sortDrawer.setOnClickListener { showSortMenu(it) }
        refreshDrawer.setOnClickListener { refreshLauncher(it) }
        settingsBtn.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        tabPersonal.setOnClickListener { renderDrawer(false) }
        tabWork.setOnClickListener { renderDrawer(true) }
        widgetArea.setOnLongClickListener { showHomeMenu(); true }
        widgetHostContainer.setOnLongClickListener { showHomeMenu(); true }

        selectionBar = findViewById(R.id.selectionBar); selectionCount = findViewById(R.id.selectionCount)
        swipeUpHandle = findViewById(R.id.swipeUpHandle)
        // Dedicated swipe-up handle at bottom of screen — always intercepts to open drawer
        swipeUpHandle.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    dragStartY = ev.y; dragStartX = ev.x; dragStartProgress = 0f; dragActivated = false
                    dragCandidate = 1  // open drawer mode
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = ev.y - dragStartY
                    if (!dragActivated && dy < -dp(4)) {
                        dragActivated = true; dragAnimator?.cancel()
                        if (drawer.visibility != View.VISIBLE) { drawer.visibility = View.VISIBLE; applyDragProgress(0f) }
                    }
                    if (dragActivated) {
                        val p = (-dy) / drawerHeightPx().coerceAtLeast(1f); applyDragProgress(p.coerceIn(0f, 1f)); true
                    } else { false }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val handled = if (dragActivated) {
                        animateDrag(if (dragProgress > 0.25f) 1f else 0f)
                        dragActivated = false; dragCandidate = 0; true
                    } else { dragCandidate = 0; false }
                    handled
                }
                else -> false
            }
        }
        selection.onChanged = { updateSelectionBar() }
        findViewById<View>(R.id.selDone).setOnClickListener { exitSelectionMode() }
        findViewById<View>(R.id.selFolder).setOnClickListener {
            val ids = selection.ids.toList()
            if (ids.isNotEmpty()) AppContextMenu.showAddToFolderDialog(this, ids) { exitSelectionMode(); renderDrawer(currentWorkTab) }
        }
        findViewById<View>(R.id.selShortcut).setOnClickListener {
            for (id in selection.ids) DesktopStore.addShortcut(this, id)
            exitSelectionMode(); renderDesktop(); renderDrawer(currentWorkTab)
        }
        findViewById<View>(R.id.selUninstall).setOnClickListener {
            val targets = selection.ids.mapNotNull { id -> apps.firstOrNull { it.id == id } }
            if (targets.isNotEmpty()) AppContextMenu.confirmUninstall(this, targets) { loadApps() }
            exitSelectionMode()
        }
        findViewById<View>(R.id.selUser).setOnClickListener {
            val pkgs = selection.ids.mapNotNull { id -> apps.firstOrNull { it.id == id }?.packageName }
            AppContextMenu.installToOtherUser(this, pkgs)
        }

        // Desktop pager setup
        desktopPager.offscreenPageLimit = 2
        desktopPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                currentDesktopPage = position
                // Save non-zero pages so "last" action can restore them
                if (position > 0) lastNonDesktopPage = position
                updateDesktopPageIndicator()
            }
        })

        drawerPager.offscreenPageLimit = 1; (drawerPager.parent as? android.view.ViewGroup)?.clipChildren = true; drawerPager.clipChildren = true
        tunePagerForSpeed(drawerPager)
        applyPagerTransformer()
        drawerPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                val a = drawerPager.adapter as? HorizontalDrawerAdapter

                prefetchAdjacentPages(position)
            }
        })
        // Snappy page scrolling: limit to one page per swipe
        (drawerPager.getChildAt(0) as? RecyclerView)?.let { rv ->
            rv.setOnFlingListener(object : RecyclerView.OnFlingListener() {
                override fun onFling(velocityX: Int, velocityY: Int): Boolean {
                    val cur = drawerPager.currentItem
                    val count = drawerPager.adapter?.itemCount ?: return false
                    val next = if (velocityX > 0) (cur + 1).coerceAtMost(count - 1) else (cur - 1).coerceAtLeast(0)
                    if (next != cur) drawerPager.setCurrentItem(next, true)
                    return true
                }
            })
        }

        applyPrefs()
        AppRepository.cached()?.let { apps = it; renderDesktop(); renderDrawer(currentWorkTab) }
        if (apps.isEmpty() || AppRepository.dirty) loadApps()
        registerPackageCallback()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button behavior — respect user preference
        // Before changing anything, save the current state for "last" action
        if (prefs().getString("home_button_action", "desktop") == "last") {
            lastDrawerWasOpen = drawer.visibility == View.VISIBLE
            lastDrawerWorkTab = currentWorkTab
        }
        val action = prefs().getString("home_button_action", "desktop") ?: "desktop"
        when (action) {
            "last" -> {
                // Restore drawer if it was open, otherwise restore last desktop page
                if (lastDrawerWasOpen) {
                    // Re-open the drawer to the tab that was active
                    if (drawer.visibility != View.VISIBLE) {
                        renderDrawer(lastDrawerWorkTab)
                        drawer.visibility = View.VISIBLE
                        applyDragProgress(1f)
                        drawer.alpha = 1f
                        homeContent.alpha = 0.65f
                    }
                } else {
                    // Restore last non-desktop page (not page 0)
                    if (lastNonDesktopPage > 0 && desktopPages.isNotEmpty()) {
                        val safe = lastNonDesktopPage.coerceIn(0, (desktopPages.size - 1).coerceAtLeast(0))
                        if (safe != currentDesktopPage) desktopPager.setCurrentItem(safe, false)
                    }
                }
            }
            else -> {
                // Default: exit to desktop first page, close drawer
                if (drawer.visibility == View.VISIBLE) showDrawer(false)
                if (currentDesktopPage != 0 && desktopPages.isNotEmpty()) {
                    desktopPager.setCurrentItem(0, true)
                }
            }
        }
    }

    private fun updateDesktopPageIndicator() {
        val show = prefs().getBoolean("show_desktop_page_numbers", false)
        if (!show) {
            desktopPageIndicator.visibility = View.GONE
            desktopPageIndicator.text = ""
            return
        }
        desktopPageIndicator.visibility = View.VISIBLE
        val total = desktopPages.size
        if (total <= 1 && !isDesktopLocked()) {
            desktopPageIndicator.text = getString(R.string.desktop_page_hint)
        } else if (total > 1) {
            desktopPageIndicator.text = "${currentDesktopPage + 1} / $total"
        } else {
            desktopPageIndicator.text = ""
        }
    }

    // ─── Multi-page Desktop Pager Adapter ─────────────────────────────
    private inner class DesktopPagerAdapter : RecyclerView.Adapter<DesktopPagerAdapter.PageVH>() {

        inner class PageVH(val grid: RecyclerView) : RecyclerView.ViewHolder(grid)

        override fun getItemCount(): Int = desktopPages.size.coerceAtLeast(1)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
            val grid = RecyclerView(parent.context).apply {
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                setPadding(dp(8), dp(4), dp(8), dp(4))
                clipToPadding = false
            }
            return PageVH(grid)
        }

        override fun onBindViewHolder(holder: PageVH, position: Int) {
            val page = desktopPages.getOrElse(position) { mutableListOf() }
            val cols = desktopCols()
            val rowsNeeded = if (page.isEmpty()) 5 else ((page.size + cols - 1) / cols).coerceAtLeast(5)
            holder.grid.layoutManager = FillingGridLayoutManager(this@HomeActivity, cols, rowsNeeded)

            val locked = isDesktopLocked()
            val adapter = DesktopAdapter(page, ::launchApp,
                onAppLongClick = { item, view, startMove ->
                    AppContextMenu.show(this@HomeActivity, view, item, apps,
                        onShortcutChanged = { renderDesktop(); renderDrawer(currentWorkTab) },
                        onAppsChanged = { loadApps() },
                        onMove = if (locked) null else startMove)
                },
                onFolderLongClick = { name, _, view, startMove ->
                    AppContextMenu.showFolderMenu(this@HomeActivity, view, name,
                        onChanged = { renderDesktop(); renderDrawer(currentWorkTab) },
                        onMove = if (locked) null else startMove)
                },
                locked = locked,
                onStartDrag = if (locked) null else { vh ->
                    // Find and start the touch-helper for this page
                    val helper = holder.grid.getTag(R.id.desktopTouchTag) as? ItemTouchHelper
                    helper?.startDrag(vh)
                }
            )
            holder.grid.adapter = adapter

            // Attach drag helper per page
            val oldHelper = holder.grid.getTag(R.id.desktopTouchTag) as? ItemTouchHelper
            oldHelper?.attachToRecyclerView(null)

            if (!locked) {
                val cb = object : ItemTouchHelper.SimpleCallback(
                    ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
                ) {
                    override fun isLongPressDragEnabled(): Boolean = true // direct drag on long-press
                    override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                        adapter.moveItem(vh.bindingAdapterPosition, target.bindingAdapterPosition); return true
                    }
                    override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {
                        // Swipe to edge = move to adjacent page
                        val e = adapter.entries[vh.bindingAdapterPosition]
                        val entryKey = when (e) { is DesktopAdapter.Entry.Shortcut -> "S:${e.app.id}"; is DesktopAdapter.Entry.Folder -> "F:${e.name}" }
                        val targetPage = when (dir) {
                            ItemTouchHelper.LEFT -> (currentDesktopPage + 1).coerceAtMost(desktopPages.size - 1)
                            ItemTouchHelper.RIGHT -> (currentDesktopPage - 1).coerceAtLeast(0)
                            else -> currentDesktopPage
                        }
                        if (targetPage != currentDesktopPage) {
                            DesktopStore.moveToPage(this@HomeActivity, entryKey, currentDesktopPage, targetPage)
                            renderDesktop()
                            desktopPager.setCurrentItem(targetPage, false)
                        }
                        adapter.notifyDataSetChanged()
                    }
                    override fun onSelectedChanged(vh: RecyclerView.ViewHolder?, actionState: Int) {
                        super.onSelectedChanged(vh, actionState)
                        desktopDragging = actionState == ItemTouchHelper.ACTION_STATE_DRAG
                        if (desktopDragging && animationsEnabled()) {
                            vh?.itemView?.animate()?.scaleX(1.08f)?.scaleY(1.08f)?.setDuration(120)?.start()
                        }
                    }
                    override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
                        super.clearView(rv, vh)
                        vh.itemView.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                        savePage(holder.bindingAdapterPosition, adapter.snapshotKeys())
                    }
                }
                val helper = ItemTouchHelper(cb)
                helper.attachToRecyclerView(holder.grid)
                holder.grid.setTag(R.id.desktopTouchTag, helper)
            } else {
                holder.grid.setTag(R.id.desktopTouchTag, null)
            }
        }
    }

    private fun savePage(pageIndex: Int, keys: List<String>) {
        if (pageIndex >= desktopPages.size) return
        val all = DesktopStore.getDesktopPages(this).map { it.toMutableList() }.toMutableList()
        while (all.size <= pageIndex) all.add(mutableListOf())
        all[pageIndex] = keys.toMutableList()
        DesktopStore.saveDesktopPages(this, all)
    }

    private fun prefetchAdjacentPages(currentPage: Int) {
        val adapter = drawerPager.adapter as? HorizontalDrawerAdapter ?: return
        val cols = gridSize().first; val rows = gridSize().second; val perPage = (cols * rows).coerceAtLeast(1)
        val entries = buildDrawerEntries(currentWorkTab)
        for (offset in listOf(-1, 1, 2)) {
            val real = adapter.realIndex(currentPage + offset); val from = real * perPage
            for (i in from until minOf(entries.size, from + perPage)) {
                when (val e = entries.getOrNull(i) ?: break) {
                    is DrawerEntry.App -> IconCache.prefetch(this, e.app, priority = 4)
                    is DrawerEntry.Folder -> e.apps.take(4).forEach { IconCache.prefetch(this, it, priority = 4) }
                }
            }
        }
    }

    override fun onStart() { super.onStart(); widgetHost.start(); widgetHost.renderAll() }
    override fun onStop() { super.onStop(); widgetHost.stop() }

    override fun onPause() { super.onPause(); flushAllPages() }
    override fun onResume() {
        super.onResume(); applyPrefs()
        if (isDesktopMode()) drawer.visibility = View.GONE
        // Only force-close the drawer on resume if it was NOT intentionally left open.
        // The drawer open state is managed by onNewIntent (home button) and explicit user gestures.
        if (AppRepository.dirty || apps.isEmpty()) loadApps() else { renderDesktop(); renderDrawer(currentWorkTab) }
        widgetHost.renderAll()
    }

    private fun flushAllPages() {
        val allKeys = desktopPages.map { page ->
            page.map { e -> when (e) { is DesktopAdapter.Entry.Shortcut -> "S:${e.app.id}"; is DesktopAdapter.Entry.Folder -> "F:${e.name}" } }
        }
        DesktopStore.saveDesktopPages(this, allKeys)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as android.content.pm.LauncherApps; packageCallback?.let { la.unregisterCallback(it) } } catch (_: Throwable) {}
    }

    private var packageCallback: android.content.pm.LauncherApps.Callback? = null
    private fun registerPackageCallback() {
        if (packageCallback != null) return
        try {
            val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as android.content.pm.LauncherApps
            val cb = object : android.content.pm.LauncherApps.Callback() {
                override fun onPackageRemoved(p: String?, u: android.os.UserHandle?) { invalidate() }
                override fun onPackageAdded(p: String?, u: android.os.UserHandle?) { invalidate() }
                override fun onPackageChanged(p: String?, u: android.os.UserHandle?) { invalidate() }
                override fun onPackagesAvailable(p: Array<out String>?, u: android.os.UserHandle?, r: Boolean) { invalidate() }
                override fun onPackagesUnavailable(p: Array<out String>?, u: android.os.UserHandle?, r: Boolean) { invalidate() }
                private fun invalidate() { AppRepository.invalidate(); runOnUiThread { loadApps() } }
            }
            la.registerCallback(cb); packageCallback = cb
        } catch (_: Throwable) {}
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun displayMode(): String = prefs().getString("app_display_mode", "drawer") ?: "drawer"
    private fun isDesktopMode(): Boolean = displayMode() == "desktop"

    private fun openMode(): String = prefs().getString("drawer_open_mode", "swipe") ?: "swipe"
    private fun drawerOrientation(): String = prefs().getString("drawer_orientation", "horizontal") ?: "horizontal"
    private fun cyclicPaging(): Boolean = prefs().getBoolean("cyclic_paging", false)
    private fun drawerBgAlpha(): Int = prefs().getInt("drawer_bg_alpha", 80).coerceIn(0, 100)


    private fun updateClockWidget() {
        val prefs = prefs()
        val showDate = prefs.getBoolean("show_date", true)
        val showIp = prefs.getBoolean("show_ip", false)
        val showSpeed = prefs.getBoolean("show_speed", false)

        applyWidgetColors()
        // Apply font to widget texts
        val tf = com.homelauncher.prime.util.FontManager.getCurrentTypeface(this)
        if (tf != android.graphics.Typeface.DEFAULT) {
            widgetClock.typeface = tf; widgetDate.typeface = tf; widgetIp.typeface = tf; widgetSpeed.typeface = tf
        }
        // Date
        if (showDate) {
            widgetDate.text = formatDate()
            widgetDate.visibility = View.VISIBLE
            widgetDate.removeCallbacks(dateUpdater)
            widgetDate.postDelayed(dateUpdater, 60_000)
        } else {
            widgetDate.visibility = View.GONE
        }

        // IP Address
        if (showIp) {
            widgetIp.text = getDeviceIp(); widgetIp.setTextColor(getWidgetTextColor("ip"))
            widgetIp.visibility = View.VISIBLE
        } else {
            widgetIp.visibility = View.GONE
        }

        // Network speed
        if (showSpeed) {
            startNetMonitor()
            widgetSpeed.visibility = View.VISIBLE
        } else {
            stopNetMonitor()
            widgetSpeed.visibility = View.GONE
        }
    }

    private val dateUpdater = object : Runnable {
        override fun run() {
            val df = java.text.SimpleDateFormat("EEEE, d MMMM yyyy", java.util.Locale("ar"))
            widgetDate.text = formatDate()
            widgetDate.postDelayed(this, 60_000)
        }
    }

    private fun formatDate(): String {
        val useHijri = prefs().getBoolean("use_hijri_date", false)
        return if (useHijri) getHijriDate() else {
            val df = java.text.SimpleDateFormat("EEEE, d MMMM yyyy", java.util.Locale("ar"))
            df.format(java.util.Date())
        }
    }

    private fun getHijriDate(): String {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                val now = java.time.chrono.HijrahDate.now()
                val day = now.get(java.time.temporal.ChronoField.DAY_OF_MONTH)
                val month = now.get(java.time.temporal.ChronoField.MONTH_OF_YEAR)
                val year = now.get(java.time.temporal.ChronoField.YEAR)
                val months = arrayOf("محرم","صفر","ربيع الأول","ربيع الثاني","جمادى الأولى","جمادى الآخرة","رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة")
                return "$day ${months.getOrElse(month - 1) {""}} $year هـ"
            }
        } catch (_: Throwable) {}
        // Fallback: approximation
        val cal = java.util.Calendar.getInstance()
        val jd = ((cal.get(java.util.Calendar.YEAR) + 4716L) * 365.25).toLong() + ((cal.get(java.util.Calendar.MONTH) + 1) * 30.6).toLong() + cal.get(java.util.Calendar.DAY_OF_MONTH) - 43
        val l = jd - 1948440 + 10632
        val n = ((l - 1) / 10631)
        val l2 = l - 10631 * n + 354
        val j = ((10985 - l2) / 5316) * ((50 * l2) / 17719) + (l2 / 5670) * ((43 * l2) / 15238)
        val l3 = l2 - ((30 - j) / 15) * ((17719 * j) / 50) - (j / 16) * ((15238 * j) / 43) + 29
        val m = ((24 * l3) / 709)
        val d = l3 - ((709 * m) / 24)
        val y = (30 * n + j - 30)
        val months = arrayOf("محرم","صفر","ربيع الأول","ربيع الثاني","جمادى الأولى","جمادى الآخرة","رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة")
        return "${d.toInt()} ${months.getOrElse(m.toInt() - 1) {""}} ${y.toInt()} هـ"
    }


    private fun getDeviceIp(): String {
        val source = prefs().getString("ip_source", "public") ?: "public"
        if (source == "public") {
            // Show cached immediately, refresh in background
            val cached = com.homelauncher.prime.util.PublicIp.getCached()
            // kick off refresh
            Thread {
                val fresh = com.homelauncher.prime.util.PublicIp.fetchBlocking()
                if (fresh != null) runOnUiThread {
                    if (::widgetIp.isInitialized && widgetIp.visibility == View.VISIBLE)
                        widgetIp.text = "IP: $fresh"
                }
            }.start()
            return if (cached != null) "IP: $cached" else "IP: جارٍ التحميل..."
        }
        // Local IP fallback
        try {
            val interfaces = java.net.NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val ni = interfaces.nextElement()
                if (ni.isLoopback || !ni.isUp) continue
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (addr is java.net.Inet4Address && !addr.isLoopbackAddress) {
                        return "IP: ${addr.hostAddress ?: "??"}"
                    }
                }
            }
        } catch (_: Throwable) {}
        try {
            val wm = getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
            val ip = wm.connectionInfo.ipAddress
            if (ip != 0) {
                return "IP: ${ip and 0xFF}.${(ip shr 8) and 0xFF}.${(ip shr 16) and 0xFF}.${(ip shr 24) and 0xFF}"
            }
        } catch (_: Throwable) {}
        return "IP: غير متصل"
    }

    private fun startNetMonitor() {
        val UNSUP = android.net.TrafficStats.UNSUPPORTED.toLong()
        lastRxBytes = android.net.TrafficStats.getTotalRxBytes()
        lastTxBytes = android.net.TrafficStats.getTotalTxBytes()
        if (lastRxBytes == UNSUP || lastTxBytes == UNSUP) {
            widgetSpeed.text = "▼ -- KB/s  ▲ -- KB/s"
            return
        }
        lastNetTime = System.currentTimeMillis()
        netMonitorHandler = Handler(Looper.getMainLooper())
        netMonitorRunnable = object : Runnable {
            override fun run() {
                val now = System.currentTimeMillis()
                val rx = android.net.TrafficStats.getTotalRxBytes()
                val tx = android.net.TrafficStats.getTotalTxBytes()
                if (rx == UNSUP || tx == UNSUP) {
                    widgetSpeed.text = "▼ -- KB/s  ▲ -- KB/s"
                    return
                }
                val elapsed = ((now - lastNetTime) / 1000f).coerceAtLeast(0.5f)
                val dlSpeed = ((rx - lastRxBytes) / elapsed / 1024f).coerceAtLeast(0f)
                val ulSpeed = ((tx - lastTxBytes) / elapsed / 1024f).coerceAtLeast(0f)
                val dl = if (dlSpeed >= 1024f) String.format("%.1f MB/s", dlSpeed / 1024f) else String.format("%.1f KB/s", dlSpeed)
                val ul = if (ulSpeed >= 1024f) String.format("%.1f MB/s", ulSpeed / 1024f) else String.format("%.1f KB/s", ulSpeed)
                widgetSpeed.text = "▼ $dl  ▲ $ul"
                lastRxBytes = rx; lastTxBytes = tx; lastNetTime = now
                netMonitorHandler?.postDelayed(this, 1500)
            }
        }
        netMonitorHandler?.post(netMonitorRunnable!!)
    }

    private fun stopNetMonitor() {
        netMonitorHandler?.removeCallbacks(netMonitorRunnable ?: return)
        netMonitorHandler = null; netMonitorRunnable = null
    }

    private fun getWidgetTextColor(key: String): Int {
        val hex = prefs().getString("widget_${key}_color", null)
        return if (!hex.isNullOrEmpty()) try { Color.parseColor(hex) } catch (_: Throwable) { Color.WHITE } else Color.WHITE
    }
    private fun applyWidgetColors() {
        widgetDate.setTextColor(getWidgetTextColor("date"))
        widgetIp.setTextColor(getWidgetTextColor("ip"))
        widgetSpeed.setTextColor(getWidgetTextColor("speed"))
        // Clock stays white by default
    }

    private val widgetPrefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key in setOf("show_date", "show_ip", "show_speed", "show_clock",
            "widget_date_color", "widget_ip_color", "widget_speed_color", "use_hijri_date", "page_transition",
            "ip_source", "show_desktop_page_numbers", "show_recents_dock", "label_font_size", "home_button_action",
            "drawer_drag_sensitivity")) {
            runOnUiThread {
                updateClockWidget(); applyPagerTransformer()
                updateDesktopPageIndicator(); renderRecentsDock()
                if (key == "label_font_size") { renderDesktop(); renderDrawer(currentWorkTab) }
            }
        }
    }
    private fun applyPrefs() {
        widgetArea.visibility = if (prefs().getBoolean("show_clock", true)) View.VISIBLE else View.GONE
        updateClockWidget()
        // Desktop mode: hide entire drawer system
        if (isDesktopMode()) {
            openDrawer.visibility = View.GONE
            drawer.visibility = View.GONE
        } else {
            openDrawer.visibility = if (openMode() == "tap") View.VISIBLE else View.GONE
        }
        drawerPager.orientation = ViewPager2.ORIENTATION_HORIZONTAL
        drawerSearch.visibility = if (prefs().getBoolean("drawer_search_enabled", true)) View.VISIBLE else View.GONE
        if (!prefs().getBoolean("drawer_search_enabled", true)) { drawerSearch.setText(""); searchQuery = "" }
        val a = (drawerBgAlpha() * 255 / 100).coerceIn(0, 255)
        drawer.setBackgroundColor(Color.argb(a, 0x0E, 0x12, 0x20))
        applyPagerTransformer()
        prefs().registerOnSharedPreferenceChangeListener(widgetPrefsListener)
        renderRecentsDock()
        updateDesktopPageIndicator()
    }

    private fun renderRecentsDock() {
        val enabled = prefs().getBoolean("show_recents_dock", false)
        if (!enabled) { dockRecents.visibility = View.GONE; return }
        val ids = com.homelauncher.prime.util.RecentApps.get(this)
        if (ids.isEmpty() || apps.isEmpty()) { dockRecents.visibility = View.GONE; return }
        val byId = apps.associateBy { it.id }
        val recentApps = ids.mapNotNull { byId[it] }.take(6)
        if (recentApps.isEmpty()) { dockRecents.visibility = View.GONE; return }
        dockRecents.visibility = View.VISIBLE
        dockRecents.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(
            this, androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL, false
        )
        val list = recentApps.toMutableList()
        dockRecents.adapter = AppGridAdapter(list, ::launchApp,
            { item, view -> AppContextMenu.show(this, view, item, apps,
                onShortcutChanged = { renderDesktop(); renderDrawer(currentWorkTab) },
                onAppsChanged = { loadApps() }) },
            iconSizeDp = 42)
    }

    private fun applyPagerTransformer() {
        // Desktop pager: NO transformer — touch targets require precise alignment
        desktopPager.setPageTransformer(null)
        // Drawer pager: apply selected transition
        if (!animationsEnabled()) { drawerPager.setPageTransformer(null); return }
        val transitionName = prefs().getString("page_transition", "fade_in") ?: "fade_in"
        if (transitionName == "none") { drawerPager.setPageTransformer(null); return }
        drawerPager.setPageTransformer(PageTransitions.get(transitionName))
    }

    private fun isDesktopLocked(): Boolean = prefs().getBoolean("desktop_locked", false)

    private fun tunePagerForSpeed(pager: ViewPager2) {
        try {
            val rv = pager.getChildAt(0) as? RecyclerView ?: return
            val tsField = RecyclerView::class.java.getDeclaredField("mTouchSlop"); tsField.isAccessible = true
            tsField.setInt(rv, (tsField.getInt(rv) / 2).coerceAtLeast(4))
            val original = rv.onFlingListener
            rv.onFlingListener = object : RecyclerView.OnFlingListener() {
                override fun onFling(vx: Int, vy: Int): Boolean {
                    val total = pager.adapter?.itemCount ?: 0
                    if (total <= 1 || abs(vx) <= abs(vy)) return original?.onFling(vx, vy) ?: false
                    val absVx = abs(vx); val cur = pager.currentItem
                    val target: Int = when {
                        absVx > 9000 -> if (vx > 0) total - 1 else 0
                        absVx > 4000 -> { val jump = (absVx / 2200).coerceAtLeast(2); if (vx > 0) (cur + jump).coerceAtMost(total - 1) else (cur - jump).coerceAtLeast(0) }
                        else -> return original?.onFling(vx, vy) ?: false
                    }
                    if (target == cur) return original?.onFling(vx, vy) ?: false
                    pager.setCurrentItem(target, true); return true
                }
            }
        } catch (_: Throwable) {}
    }

    private fun gridSize(): Pair<Int, Int> {
        val raw = prefs().getString("grid_size", "5x5") ?: "5x5"
        val parts = raw.lowercase().split("x")
        return (parts.getOrNull(0)?.toIntOrNull()?.coerceIn(2, 12) ?: 5) to (parts.getOrNull(1)?.toIntOrNull()?.coerceIn(2, 12) ?: 5)
    }

    private fun desktopCols(): Int = prefs().getString("desktop_cols", "4")?.toIntOrNull() ?: 4
    private fun sortMode(): String = prefs().getString("sort_mode", "name") ?: "name"
    private fun setSortMode(mode: String) { prefs().edit().putString("sort_mode", mode).apply() }

    private fun loadApps() {
        val cached = AppRepository.cached()
        if (cached != null && AppRepository.initialLoadComplete && !AppRepository.dirty) {
            apps = cached; warmBothDrawerProfiles(); renderDesktop(); renderDrawer(currentWorkTab)
            return
        }
        // Show whatever we have instantly (even a stale JSON cache) so the screen is never empty.
        val fast = AppRepository.loadFast(this)
        if (fast.isNotEmpty()) { apps = fast; warmBothDrawerProfiles(); renderDesktop(); renderDrawer(currentWorkTab) }
        // Kick off a full refresh in the background if we still need one.
        if (!AppRepository.initialLoadComplete || AppRepository.dirty) {
            CoroutineScope(Dispatchers.IO).launch {
                val list = AppRepository.loadAll(this@HomeActivity)
                withContext(Dispatchers.Main) {
                    if (list.size != apps.size || list.hashCode() != apps.hashCode()) {
                        apps = list; warmBothDrawerProfiles(); renderDesktop(); renderDrawer(currentWorkTab)
                    }
                }
            }
        }
    }

    // ─── Desktop rendering (multi-page) ────────────────────────────────

    /** Desktop-pages mode (Xiaomi): personal apps + user-created folders in their saved order,
     * then work/other-user apps grouped as one folder per user name. */
    private fun renderDesktopAllApps() {
        val showUserFolders = prefs().getBoolean("show_user_folders", true)

        // 1) Build ordered entries: user-created folders first (they may contain personal apps),
        //    then remaining personal apps as shortcuts, then work/multi-user apps as user-named folders.
        val personalApps = apps.filter { !it.isWork }
        val byId = personalApps.associateBy { it.id }
        val userFolders = DesktopStore.getFolders(this)
        val claimed = HashSet<String>()
        val orderedEntries = ArrayList<DesktopAdapter.Entry>()

        for ((name, ids) in userFolders) {
            val members = ids.mapNotNull { byId[it] }
            if (members.isNotEmpty()) {
                orderedEntries.add(DesktopAdapter.Entry.Folder(name, members))
                claimed.addAll(members.map { it.id })
            }
        }
        for (a in personalApps.filter { !claimed.contains(it.id) }) {
            orderedEntries.add(DesktopAdapter.Entry.Shortcut(a))
        }
        if (showUserFolders) {
            val workApps = apps.filter { it.isWork }
            if (workApps.isNotEmpty()) {
                val userGroups = workApps.groupBy { it.userLabel }.toSortedMap()
                for ((name, members) in userGroups) {
                    orderedEntries.add(DesktopAdapter.Entry.Folder(name, members))
                }
            }
        }

        // 2) Map entries by their storage key
        val entryByKey = HashMap<String, DesktopAdapter.Entry>()
        for (e in orderedEntries) {
            val k = when (e) {
                is DesktopAdapter.Entry.Shortcut -> "S:${e.app.id}"
                is DesktopAdapter.Entry.Folder -> "F:${e.name}"
            }
            entryByKey[k] = e
        }

        // 3) Reconstruct pages from stored layout; append remaining entries preserving order.
        val storedPages = DesktopStore.getDesktopPages(this)
        desktopPages.clear()
        val placed = HashSet<String>()
        for (pageKeys in storedPages) {
            val page = ArrayList<DesktopAdapter.Entry>()
            for (key in pageKeys) {
                val e = entryByKey[key] ?: continue
                page.add(e); placed.add(key)
            }
            desktopPages.add(page)
        }
        val cols = desktopCols()
        val perPage = (cols * 5).coerceAtLeast(cols * 4)
        val remaining = orderedEntries.filter { e ->
            val k = when (e) {
                is DesktopAdapter.Entry.Shortcut -> "S:${e.app.id}"
                is DesktopAdapter.Entry.Folder -> "F:${e.name}"
            }
            k !in placed
        }
        if (remaining.isNotEmpty()) {
            if (desktopPages.isEmpty()) desktopPages.add(ArrayList())
            val last = desktopPages.last()
            val freeInLast = (perPage - last.size).coerceAtLeast(0)
            var i = 0
            if (freeInLast > 0) {
                val take = minOf(freeInLast, remaining.size)
                last.addAll(remaining.subList(0, take))
                i = take
            }
            while (i < remaining.size) {
                val chunk = remaining.subList(i, minOf(remaining.size, i + perPage))
                desktopPages.add(ArrayList(chunk))
                i += perPage
            }
        }
        if (desktopPages.isEmpty()) desktopPages.add(ArrayList())

        val adapter = DesktopPagerAdapter()
        desktopPager.adapter = adapter
        val target = currentDesktopPage.coerceIn(0, (desktopPages.size - 1).coerceAtLeast(0))
        desktopPager.setCurrentItem(target, false)
        currentDesktopPage = target
        updateDesktopPageIndicator()
    }

    private fun renderDesktop() {
        val cols = desktopCols()
        if (isDesktopMode()) {
            // Desktop pages mode: show ALL apps across pages (like Xiaomi)
            renderDesktopAllApps(); return
        }
        val shortcutIds = DesktopStore.getShortcutIds(this)
        val showUserFolders = prefs().getBoolean("show_user_folders", true)
        val allEntries = HashMap<String, DesktopAdapter.Entry>()
        for (app in apps) if (shortcutIds.contains(app.id)) allEntries["S:${app.id}"] = DesktopAdapter.Entry.Shortcut(app)
        if (showUserFolders) {
            for ((name, members) in AppRepository.groupByUser(apps))
                allEntries["F:$name"] = DesktopAdapter.Entry.Folder(name, members)
        }

        val storedPages = DesktopStore.getDesktopPages(this)
        desktopPages.clear()
        val placed = HashSet<String>()

        for (pageKeys in storedPages) {
            val page = ArrayList<DesktopAdapter.Entry>()
            for (key in pageKeys) {
                val entry = allEntries[key]
                if (entry != null) { page.add(entry); placed.add(key) }
            }
            desktopPages.add(page)
        }
        // Unplaced entries go to last page
        val unplaced = ArrayList<DesktopAdapter.Entry>()
        for (e in allEntries) if (e.key !in placed) unplaced.add(e.value)
        if (unplaced.isNotEmpty()) {
            if (desktopPages.isEmpty()) desktopPages.add(ArrayList())
            desktopPages.last().addAll(unplaced)
        }
        if (desktopPages.isEmpty()) desktopPages.add(ArrayList())

        // Re-attach adapter
        val adapter = DesktopPagerAdapter()
        desktopPager.adapter = adapter
        val target = currentDesktopPage.coerceIn(0, (desktopPages.size - 1).coerceAtLeast(0))
        desktopPager.setCurrentItem(target, false)
        currentDesktopPage = target
        updateDesktopPageIndicator()
    }

    private fun sortApps(list: List<AppItem>): List<AppItem> {
        val pm = packageManager
        return when (sortMode()) {
            "new" -> list.sortedByDescending { try { pm.getPackageInfo(it.packageName, 0).firstInstallTime } catch (_: Throwable) { 0L } }
            "old" -> list.sortedBy { try { pm.getPackageInfo(it.packageName, 0).firstInstallTime } catch (_: Throwable) { 0L } }
            else  -> list.sortedBy { it.label.lowercase() }
        }
    }

    private fun buildDrawerEntries(work: Boolean): List<DrawerEntry> {
        val filtered = if (!work) apps.filter { !it.isWork } else apps.filter { it.isWork }
        val byId = filtered.associateBy { it.id }
        val folders = DesktopStore.getFolders(this); val foldersEntries = mutableListOf<DrawerEntry>()
        val claimed = HashSet<String>()
        for ((name, ids) in folders) {
            val members = ids.mapNotNull { byId[it] }
            if (members.isNotEmpty()) { foldersEntries += DrawerEntry.Folder(name, members); claimed += members.map { it.id } }
        }
        val remaining = filtered.filter { !claimed.contains(it.id) }
        if (work) {
            val prefix = getString(R.string.user_folder_prefix)
            return foldersEntries + remaining.groupBy { it.userLabel }.toSortedMap().map { (lbl, m) -> DrawerEntry.Folder("$prefix · $lbl", sortApps(m)) }
        }
        return foldersEntries + sortApps(remaining).map { DrawerEntry.App(it) }
    }

    private fun iconsFromVisibleEntries(entries: List<DrawerEntry>, visibleCells: Int): List<AppItem> {
        val out = ArrayList<AppItem>(visibleCells * 2)
        entries.take(visibleCells).forEach { entry ->
            when (entry) {
                is DrawerEntry.App -> out += entry.app
                is DrawerEntry.Folder -> out.addAll(entry.apps.take(4))
            }
        }
        return out
    }

    private fun prefetchDrawerEntries(entries: List<DrawerEntry>, cols: Int, rows: Int, pages: Int, priority: Int) {
        IconCache.prefetchAll(this, iconsFromVisibleEntries(entries, cols * rows * pages), priority = priority)
    }

    private fun warmBothDrawerProfiles() {
        val (cols, rows) = gridSize()
        prefetchDrawerEntries(buildDrawerEntries(false), cols, rows, pages = 2, priority = 1)
        prefetchDrawerEntries(buildDrawerEntries(true), cols, rows, pages = 2, priority = 2)
    }

    private fun renderDrawer(work: Boolean) {
        currentWorkTab = work; tabPersonal.alpha = if (work) 0.5f else 1f; tabWork.alpha = if (work) 1f else 0.5f
        val (cols, rows) = gridSize(); var entries = buildDrawerEntries(work)
        val q = searchQuery.lowercase()
        if (q.isNotEmpty()) entries = entries.mapNotNull { e -> when (e) {
            is DrawerEntry.App -> if (e.app.label.lowercase().contains(q)) e else null
            is DrawerEntry.Folder -> { val members = e.apps.filter { it.label.lowercase().contains(q) }; when { e.name.lowercase().contains(q) -> e; members.isNotEmpty() -> DrawerEntry.Folder(e.name, members); else -> null } }
        } }
        prefetchDrawerEntries(entries, cols, rows, pages = 2, priority = 0)
        if (q.isEmpty()) prefetchDrawerEntries(buildDrawerEntries(!work), cols, rows, pages = 2, priority = 3)
        val isVertical = drawerOrientation() == "vertical"
        val onAppClickCb: (AppItem, View) -> Unit = ::launchApp
        val onAppLongCb: (AppItem, View) -> Unit = { item, v -> AppContextMenu.show(this, v, item, apps, onShortcutChanged = { renderDesktop(); renderDrawer(currentWorkTab) }, onAppsChanged = { loadApps() }, onEnterSelectionMode = { firstId -> enterSelectionMode(firstId) }) }
        val onFolderLongCb: (String, View) -> Unit = { name, v -> AppContextMenu.showFolderMenu(this, v, name, onChanged = { renderDrawer(currentWorkTab) }, onMove = null) }
        if (isVertical) {
            val iconDp = when { cols >= 9 -> 36; cols >= 6 -> 48; else -> 56 }
            drawerVertical.layoutManager = GridLayoutManager(this, cols)
            val vAdapter = DrawerCellAdapter(entries.toMutableList(), iconDp, onAppClickCb, onAppLongCb, onFolderLongCb, selection)
            drawerVertical.adapter = vAdapter
            drawerVerticalTouchHelper?.attachToRecyclerView(null)
            val cb = object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0) {
                override fun isLongPressDragEnabled() = false
                override fun onMove(rv: RecyclerView, src: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean { vAdapter.moveItem(src.bindingAdapterPosition, target.bindingAdapterPosition); return true }
                override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {}
            }
            drawerVerticalTouchHelper = ItemTouchHelper(cb).also { it.attachToRecyclerView(drawerVertical) }
        } else {
            drawerVertical.visibility = View.GONE; drawerPager.visibility = View.VISIBLE
            val adapter = HorizontalDrawerAdapter(entries, cols, rows, onAppClickCb, onAppLongCb, onFolderLongCb, selection, cyclicMode = cyclicPaging())
            drawerPager.adapter = adapter; drawerPager.setCurrentItem(adapter.startPosition(), false)
            // Prefetch first page icons
            if (entries.isNotEmpty()) {
                val firstPage = entries.take(cols * rows)
                for (entry in firstPage) {
                    when (entry) {
                        is DrawerEntry.App -> IconCache.prefetch(this, entry.app)
                        is DrawerEntry.Folder -> entry.apps.take(3).forEach { IconCache.prefetch(this, it) }
                    }
                }
            }
        }
    }

    private fun enterSelectionMode(firstId: String) { selection.active = true; selection.ids.clear(); selection.ids.add(firstId); updateSelectionBar(); renderDrawer(currentWorkTab) }
    private fun exitSelectionMode() { selection.active = false; selection.ids.clear(); updateSelectionBar(); renderDrawer(currentWorkTab) }
    private fun updateSelectionBar() {
        if (selection.active) { selectionBar.visibility = View.VISIBLE; selectionCount.text = getString(R.string.selection_count, selection.ids.size) } else selectionBar.visibility = View.GONE
    }

    private fun showSortMenu(anchor: View) {
        AppContextMenu.showStyledMenu(this, anchor, listOf(
            getString(R.string.sort_by_name) to { setSortMode("name"); renderDrawer(currentWorkTab) },
            getString(R.string.sort_by_install_new) to { setSortMode("new"); renderDrawer(currentWorkTab) },
            getString(R.string.sort_by_install_old) to { setSortMode("old"); renderDrawer(currentWorkTab) }
        ))
    }

    private fun refreshLauncher(anchor: View) {
        anchor.startAnimation(android.view.animation.RotateAnimation(0f, 360f, android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f, android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f).apply { duration = 700; interpolator = DecelerateInterpolator(); repeatCount = 1 })
        IconCache.clear(); AppRepository.invalidate(); loadApps()
        Toast.makeText(this, R.string.refresh_done, Toast.LENGTH_SHORT).show()
    }

    // ─── Home menu (long-press empty) with page management ─────────────
    private fun showHomeMenu() {
        if (drawer.visibility == View.VISIBLE) return
        val anchor = if (widgetArea.visibility == View.VISIBLE) widgetArea else homeContent
        val items = mutableListOf<Pair<CharSequence, () -> Unit>>()
        items += getString(R.string.menu_add_widget) to { widgetHost.pickWidget() }
        items += getString(R.string.menu_settings) to { startActivity(Intent(this, SettingsActivity::class.java)) }
        items += getString(R.string.menu_wallpaper) to { try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), getString(R.string.menu_wallpaper))) } catch (_: Throwable) {} }
        // Page management
        if (!isDesktopLocked()) {
            items += getString(R.string.desktop_add_page) to {
                val pages = DesktopStore.addDesktopPage(this, currentDesktopPage)
                // Sync entries
                renderDesktop()
                desktopPager.setCurrentItem((currentDesktopPage + 1).coerceAtMost(pages.size - 1), true)
            }
            if (desktopPages.size > 1) {
                items += getString(R.string.desktop_remove_page) to {
                    flushAllPages()
                    val pages = DesktopStore.removeDesktopPage(this, currentDesktopPage)
                    renderDesktop()
                    desktopPager.setCurrentItem(currentDesktopPage.coerceAtMost(pages.size - 1), false)
                }
            }
        }
        AppContextMenu.showStyledMenu(this, anchor, items)
    }

    // ─── Drawer show/hide ──────────────────────────────────────────────
    private fun showDrawer(show: Boolean) {
        if (show) {
            if (apps.isNotEmpty()) warmBothDrawerProfiles()
            if (!isDesktopMode() && drawer.visibility != View.VISIBLE) { drawer.visibility = View.VISIBLE; applyDragProgress(0f); drawer.post { animateDrag(1f) }; return }
            if (!isDesktopMode()) animateDrag(1f)
        } else {
            animateDrag(0f); drawerSearch.setText(""); searchQuery = ""
            try { val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager; imm.hideSoftInputFromWindow(drawerSearch.windowToken, 0) } catch (_: Throwable) {}
        }
    }

    private fun drawerHeightPx(): Float = if (drawer.height > 0) drawer.height.toFloat() else resources.displayMetrics.heightPixels.toFloat()

    private fun applyDragProgress(p: Float) {
        val pp = p.coerceIn(0f, 1f); dragProgress = pp
        val h = drawerHeightPx(); drawer.translationY = (1f - pp) * h
        if (animationsEnabled()) {
            drawer.alpha = (0.2f + 0.8f * pp).coerceAtMost(1f)
            val scale = 1f - 0.04f * pp; homeContent.scaleX = scale; homeContent.scaleY = scale; homeContent.alpha = 1f - 0.35f * pp
            homeContent.translationY = -pp * dp(12)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) try { homeContent.setRenderEffect(if (pp > 0.01f) RenderEffect.createBlurEffect(pp * 22f, pp * 22f, Shader.TileMode.CLAMP) else null) } catch (_: Throwable) {}
        } else {
            drawer.alpha = 1f; homeContent.scaleX = 1f; homeContent.scaleY = 1f; homeContent.alpha = 1f; homeContent.translationY = 0f
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) try { homeContent.setRenderEffect(null) } catch (_: Throwable) {}
        }
    }

    private fun animateDrag(target: Float) {
        dragAnimator?.cancel(); val from = dragProgress
        if (from == target) { applyDragProgress(target); if (target == 0f) drawer.visibility = View.GONE; return }
        if (!isDesktopMode() && target > 0f && drawer.visibility != View.VISIBLE) drawer.visibility = View.VISIBLE
        val anim = ValueAnimator.ofFloat(from, target); val base = transitionMs()
        anim.duration = if (animationsEnabled()) { if (target > from) (base * (target - from) * 1.3f).toLong().coerceAtLeast(120L) else (base * (from - target)).toLong().coerceAtLeast(140L) } else 0L
        anim.interpolator = if (animationsEnabled() && target > from) OvershootInterpolator(0.6f) else DecelerateInterpolator(1.0f)
        anim.addUpdateListener { applyDragProgress(it.animatedValue as Float) }
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (target <= 0f) { drawer.visibility = View.GONE; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) try { homeContent.setRenderEffect(null) } catch (_: Throwable) {}; homeContent.alpha = 1f; homeContent.scaleX = 1f; homeContent.scaleY = 1f; homeContent.translationY = 0f }
            }
        })
        dragAnimator = anim; anim.start()
    }

    // ─── Gesture handling ──────────────────────────────────────────────
    private fun handleDragTouch(ev: MotionEvent): Boolean {
        // Suppress drawer gestures while dragging a desktop icon
        if (desktopDragging) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragStartY = ev.y; dragStartX = ev.x; dragStartProgress = dragProgress; dragActivated = false
                dragCandidate = when {
                    drawer.visibility == View.VISIBLE -> if (canDragCloseFrom(ev)) 2 else 0
                    !isDesktopMode() && openMode() == "swipe" -> 1
                    else -> 0
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragCandidate == 0) return false
                val dy = ev.y - dragStartY; val dx = ev.x - dragStartX
                // Guard: if horizontal movement dominates, this is a page scroll — don't steal it
                if (abs(dx) > abs(dy) * 1.2f) { dragCandidate = 0; return false }
                if (!dragActivated) {
                    val neededSlop = if (dragCandidate == 1) drawerOpenSlopPx() else drawerCloseSlopPx()
                    if ((dragCandidate == 1 && dy < -neededSlop) || (dragCandidate == 2 && dy > neededSlop)) {
                        dragActivated = true; dragAnimator?.cancel()
                        if (!isDesktopMode() && drawer.visibility != View.VISIBLE) {
                            drawer.visibility = View.VISIBLE; applyDragProgress(0f)
                        }
                    }
                }
                if (dragActivated) {
                    val p = (dragStartProgress + (-dy) / drawerHeightPx()).coerceIn(0f, 1f)
                    applyDragProgress(p); return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragActivated) {
                    // Opening: fixed 25% threshold (easy to open). Closing: fixed 70%.
                    val openThreshold = 0.25f
                    val closeThreshold = 0.70f
                    val open = if (dragCandidate == 1) dragProgress > openThreshold else dragProgress > closeThreshold
                    animateDrag(if (open) 1f else 0f)
                    dragActivated = false; dragCandidate = 0; return true
                }
                dragActivated = false; dragCandidate = 0
            }
        }
        return false
    }

    /**
     * Only allow drag-to-close when the touch starts on the header,
     * search bar, or selection bar — NEVER on the content grid.
     * This completely separates horizontal page-swiping from vertical closing.
     */
    private fun canDragCloseFrom(ev: MotionEvent): Boolean {
        // Header area (tabs + buttons): close from here allowed
        val hdrLoc = IntArray(2); drawerHeader.getLocationOnScreen(hdrLoc)
        if (ev.rawY >= hdrLoc[1] && ev.rawY <= hdrLoc[1] + drawerHeader.height) return true
        // Selection bar: allowed when visible
        if (selectionBar.visibility == View.VISIBLE) {
            val selLoc = IntArray(2); selectionBar.getLocationOnScreen(selLoc)
            if (ev.rawY >= selLoc[1] && ev.rawY <= selLoc[1] + selectionBar.height) return true
        }
        // Search bar: allowed when visible and touch is on it
        if (drawerSearch.visibility == View.VISIBLE) {
            val searchLoc = IntArray(2); drawerSearch.getLocationOnScreen(searchLoc)
            if (ev.rawY >= searchLoc[1] && ev.rawY <= searchLoc[1] + drawerSearch.height) return true
        }
        // Content area (ViewPager2 / RecyclerView): NEVER allow close from here
        return false
    }

    private fun launchApp(item: AppItem, source: View) {
        com.homelauncher.prime.util.RecentApps.record(this, item.id)
        renderRecentsDock()
        source.animate().scaleX(0.92f).scaleY(0.92f).setDuration(60).withEndAction { source.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }
        AppGridAdapter.launch(this, item, source)
    }

    private fun expandNotifications() {
        try { val sb = getSystemService("statusbar"); val m = Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel"); m.invoke(sb) } catch (_: Throwable) { toast("غير مدعوم على هذا الجهاز") }
    }

    private fun lockNow() {
        if (prefs().getString("lock_method", "root") == "root" && RootUtil.lockScreen()) return
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (dpm.isAdminActive(IntentUtil.adminComponent(this))) dpm.lockNow() else toast("Enable Device Admin in settings")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (selection.active) exitSelectionMode() else if (drawer.visibility == View.VISIBLE) showDrawer(false) else if (isDesktopMode()) super.onBackPressed() else super.onBackPressed()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { if (widgetHost.onActivityResult(requestCode, resultCode, data)) return; super.onActivityResult(requestCode, resultCode, data) }

    // Track horizontal movement to lock out vertical closing
    private var gestureLockedHorizontal: Boolean = false

    // Notification badge receiver
    private val badgeReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            val pkg = intent?.getStringExtra("pkg") ?: return
            // Refresh desktop and drawer to show updated badge count
            renderDesktop(); renderDrawer(currentWorkTab)
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        try {
            if (!desktopDragging) {
                if (drawer.visibility != View.VISIBLE) {
                    // Only feed to homeDetector when the gesture is clearly vertical.
                    // If horizontal movement already dominates, skip it to avoid stealing ViewPager scrolls.
                    if (!isDesktopMode()) {
                        val dx = ev.x - lpDownX; val dy = ev.y - lpDownY
                        if (abs(dy) >= abs(dx)) homeDetector.onTouchEvent(ev)
                    }
                    handleHomeLongPress(ev)
                } else {
                    drawerDetector.onTouchEvent(ev)
                }
            }
            // Horizontal gesture detection: lock out vertical closing
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> gestureLockedHorizontal = false
                MotionEvent.ACTION_MOVE -> {
                    if (drawer.visibility == View.VISIBLE && !gestureLockedHorizontal && abs(ev.x - dragStartX) > drawerCloseSlopPx() * 2) {
                        gestureLockedHorizontal = true
                    }
                }
            }
        } catch (_: Throwable) {}
        val consumed = try { if (!desktopDragging && !gestureLockedHorizontal) handleDragTouch(ev) else false } catch (_: Throwable) { false }
        if (consumed) { cancelLongPress(); val cancel = MotionEvent.obtain(ev); cancel.action = MotionEvent.ACTION_CANCEL; super.dispatchTouchEvent(cancel); cancel.recycle(); return true }
        return super.dispatchTouchEvent(ev)
    }

    private fun handleHomeLongPress(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                cancelLongPress(); lpDownX = ev.rawX; lpDownY = ev.rawY; lpFired = false
                // Check if touch is on a desktop item → skip long-press (handled by adapter/recycler)
                val loc = IntArray(2)
                // Use the current page's RecyclerView from ViewPager2
                val currentGrid = (desktopPager.getChildAt(0) as? RecyclerView)
                if (currentGrid != null) {
                    currentGrid.getLocationOnScreen(loc)
                    val x = ev.rawX; val y = ev.rawY
                    if (x >= loc[0] && x <= loc[0] + currentGrid.width && y >= loc[1] && y <= loc[1] + currentGrid.height && currentGrid.findChildViewUnder(x - loc[0], y - loc[1]) != null) return
                }
                lpRunnable = Runnable { if (drawer.visibility != View.VISIBLE && !dragActivated && !desktopDragging) { lpFired = true; showHomeMenu() } }
                lpHandler.postDelayed(lpRunnable!!, longPressMs())
            }
            MotionEvent.ACTION_MOVE -> { if (kotlin.math.hypot(ev.rawX - lpDownX, ev.rawY - lpDownY) > touchSlop) cancelLongPress() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> cancelLongPress()
        }
    }

    private fun cancelLongPress() { lpRunnable?.let { lpHandler.removeCallbacks(it) }; lpRunnable = null }
}
