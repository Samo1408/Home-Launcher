package com.homelauncher.prime.ui

import android.app.Dialog
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.TextView
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.color.MaterialColors
import com.homelauncher.prime.R
import com.homelauncher.prime.data.AppItem
import com.homelauncher.prime.util.DesktopStore
import com.homelauncher.prime.util.IconCache
import com.homelauncher.prime.util.IntentUtil

object FolderPopup {

    private fun folderGrid(ctx: Context): Pair<Int, Int> {
        val prefs = PreferenceManager.getDefaultSharedPreferences(ctx)
        val raw = prefs.getString("folder_grid_size", "4x4") ?: "4x4"
        val parts = raw.lowercase().split("x")
        val cols = parts.getOrNull(0)?.toIntOrNull()?.coerceIn(2, 8) ?: 4
        val rows = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(2, 8) ?: 4
        return cols to rows
    }

    private fun folderOrientation(ctx: Context): String =
        PreferenceManager.getDefaultSharedPreferences(ctx)
            .getString("folder_orientation", "horizontal") ?: "horizontal"

    /**
     * Open a folder. Selection (when triggered via "تحديد" from the long-press
     * menu of an app inside the folder) is scoped to this folder only — taps
     * highlight/deselect the folder's apps and never leak to the underlying
     * drawer.
     */
    fun show(
        ctx: Context,
        folderName: String,
        apps: List<AppItem>,
        onClick: (AppItem, View) -> Unit,
        onLongClick: (AppItem, View) -> Unit
    ) {
        val (cols, rows) = folderGrid(ctx)
        val vertical = folderOrientation(ctx) == "vertical"

        val visibleApps = if (vertical) {
            apps.toMutableList()
        } else {
            val capacity = (cols * rows).coerceAtLeast(1)
            apps.take(capacity).toMutableList()
        }
        IconCache.prefetchAll(ctx, visibleApps, priority = 0)

        val d = Dialog(ctx, R.style.Theme_HomeLauncher)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.setContentView(R.layout.dialog_folder)
        d.findViewById<TextView>(R.id.title).apply {
            text = folderName
            val tf = com.homelauncher.prime.util.FontManager.getCurrentTypeface(ctx)
            if (tf != android.graphics.Typeface.DEFAULT) typeface = tf
        }
        val rv = d.findViewById<RecyclerView>(R.id.grid)
        val selBar = d.findViewById<View>(R.id.folderSelectionBar)
        val selCount = d.findViewById<TextView>(R.id.folderSelectionCount)
        val selRemove = d.findViewById<ImageButton>(R.id.folderSelRemove)
        val selUninstall = d.findViewById<ImageButton>(R.id.folderSelUninstall)
        val selDone = d.findViewById<ImageButton>(R.id.folderSelDone)

        val iconDp: Int = when {
            cols >= 7 -> 36
            cols >= 5 -> 44
            cols >= 4 -> 52
            else -> 60
        }

        rv.layoutManager = GridLayoutManager(ctx, cols)
        if (vertical) rv.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        else rv.setBackgroundColor(
            MaterialColors.getColor(rv, com.google.android.material.R.attr.colorSurface)
        )

        // Local selection state, scoped to this folder dialog only.
        val selection = DrawerCellAdapter.SelectionState()

        // Build entries as App entries — folders cannot contain folders.
        val entries: MutableList<DrawerEntry> =
            visibleApps.mapTo(mutableListOf()) { DrawerEntry.App(it) }

        val adapter = DrawerCellAdapter(
            entries, iconDp,
            onAppClick = { a, v ->
                if (selection.active) return@DrawerCellAdapter
                onClick(a, v); d.dismiss()
            },
            onAppLongClick = { a, v ->
                // Open the standard app menu, but route "تحديد" into THIS
                // folder's selection state — not the drawer behind us.
                AppContextMenu.show(
                    ctx, v, a, visibleApps,
                    onShortcutChanged = {},
                    onAppsChanged = {},
                    onEnterSelectionMode = { id ->
                        if (!selection.active) {
                            selection.active = true
                        }
                        if (selection.ids.add(id)) {
                            selection.onChanged?.invoke()
                        }
                        // Refresh visuals
                        rv.adapter?.notifyDataSetChanged()
                    },
                    onMove = null
                )
            },
            onFolderLongClick = { _, _ -> },
            selection = selection
        )
        rv.adapter = adapter

        fun updateBar() {
            if (selection.active && selection.ids.isNotEmpty()) {
                selBar.visibility = View.VISIBLE
                selCount.text = ctx.getString(R.string.selection_count, selection.ids.size)
            } else {
                selBar.visibility = View.GONE
                if (selection.active) {
                    selection.active = false
                    adapter.notifyDataSetChanged()
                }
            }
        }
        selection.onChanged = { updateBar() }

        selDone.setOnClickListener {
            selection.active = false
            selection.ids.clear()
            updateBar()
            adapter.notifyDataSetChanged()
        }
        selRemove.setOnClickListener {
            val ids = selection.ids.toList()
            for (id in ids) DesktopStore.removeAppFromFolder(ctx, folderName, id)
            d.dismiss()
        }
        selUninstall.setOnClickListener {
            val targets = visibleApps.filter { selection.ids.contains(it.id) }
            for (a in targets) IntentUtil.uninstall(ctx, a.packageName, a.user)
            selection.active = false
            selection.ids.clear()
            updateBar()
        }

        // Drag-to-reorder inside the folder (long-press disabled — the
        // long-press is reserved for the context menu).
        val cb = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or
                ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            override fun isLongPressDragEnabled(): Boolean = false
            override fun onMove(
                rv2: RecyclerView,
                vh: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                if (selection.active) return false
                val from = vh.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                adapter.moveItem(from, to)
                return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {}
        }
        ItemTouchHelper(cb).attachToRecyclerView(rv)

        // Keep onLongClick signature compatibility: ignored here because
        // long-press now opens AppContextMenu through onAppLongClick above.
        @Suppress("UNUSED_VARIABLE") val unused = onLongClick

        d.show()
        d.window?.let { w ->
            w.setBackgroundDrawableResource(android.R.color.transparent)
            w.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            w.setGravity(Gravity.CENTER)
            w.setDimAmount(0f)
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        }
    }
}
