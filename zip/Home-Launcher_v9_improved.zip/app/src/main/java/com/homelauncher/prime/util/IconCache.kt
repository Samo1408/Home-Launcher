package com.homelauncher.prime.util

import android.content.Context
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.UserHandle
import android.os.UserManager
import android.util.LruCache
import android.widget.ImageView
import com.homelauncher.prime.data.AppItem
import java.io.File
import java.io.FileOutputStream
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

object IconCache {
    // 32 MB keeps both Personal + Work first pages hot; avoids icon reloads while profile switching.
    private const val MAX_MEMORY = 32768
    private const val POOL_CORE = 2
    private const val POOL_MAX  = 4
    private const val TAG_KEY = 0x7f0a1001

    private val memCache = object : LruCache<String, Drawable>(MAX_MEMORY) {
        override fun sizeOf(key: String, value: Drawable): Int {
            val w = value.intrinsicWidth.coerceAtLeast(1)
            val h = value.intrinsicHeight.coerceAtLeast(1)
            return (w * h * 4) / 1024
        }
    }

    private val queued = Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())
    private val queue = PriorityBlockingQueue<Runnable>(128)
    private val executor = ThreadPoolExecutor(POOL_CORE, POOL_MAX, 15L, TimeUnit.SECONDS, queue) { r ->
        Thread(r, "IconCache").apply { isDaemon = true; priority = Thread.MIN_PRIORITY + 1 }
    }
    private val main = Handler(Looper.getMainLooper())

    fun clear() { memCache.evictAll() }
    fun get(id: String): Drawable? = memCache.get(id)

    fun load(ctx: Context, item: AppItem, target: ImageView) {
        val id = item.id
        target.setTag(TAG_KEY, id)
        val cached = memCache.get(id)
        if (cached != null) { target.animate().cancel(); target.alpha = 1f; target.setImageDrawable(cached); target.setBackgroundColor(0); return }
        val appCtx = ctx.applicationContext
        val diskCached = loadFromDisk(appCtx, id)
        if (diskCached != null) { target.animate().cancel(); target.alpha = 1f; target.setImageDrawable(diskCached); target.setBackgroundColor(0); return }
        target.animate().cancel()
        target.alpha = 1f
        target.setImageDrawable(null)
        target.setBackgroundColor(0x14FFFFFF)
        executor.execute(PriorityRunnable(-1) {
            val drawable = loadDrawableFast(appCtx, item)
            if (drawable != null) {
                main.post {
                    if (target.getTag(TAG_KEY) == id) {
                        target.animate().cancel()
                        target.setBackgroundColor(0)
                        target.setImageDrawable(drawable)
                        target.alpha = 1f
                    }
                }
            } else {
                main.post { if (target.getTag(TAG_KEY) == id) target.setBackgroundColor(0) }
            }
        })
    }

    fun prefetch(ctx: Context, item: AppItem, priority: Int = 10) {
        val id = item.id
        if (memCache.get(id) != null) return
        if (!queued.add(id)) return
        val appCtx = ctx.applicationContext
        val diskFile = diskPath(appCtx, id)
        if (diskFile.exists()) {
            executor.execute(PriorityRunnable(priority.coerceAtMost(5)) {
                try {
                    loadFromDisk(appCtx, id) ?: loadDrawableFast(appCtx, item)
                } catch (_: Throwable) {
                } finally {
                    queued.remove(id)
                }
            })
            return
        }
        executor.execute(PriorityRunnable(priority) {
            try {
                loadDrawableFast(appCtx, item)
            } finally {
                queued.remove(id)
            }
        })
    }

    fun prefetchAll(ctx: Context, items: List<AppItem>, priority: Int = 8, limit: Int = Int.MAX_VALUE) {
        val appCtx = ctx.applicationContext
        items.asSequence().take(limit).forEachIndexed { index, item ->
            val id = item.id
            if (memCache.get(id) == null && queued.add(id)) {
                executor.execute(PriorityRunnable(priority + (index / 48)) {
                    try {
                        loadDrawableFast(appCtx, item)
                    } finally {
                        queued.remove(id)
                    }
                })
            }
        }
    }

    private fun loadDrawableFast(appCtx: Context, item: AppItem): Drawable? {
        val id = item.id
        // 1. Memory
        memCache.get(id)?.let { return it }
        // 2. Disk (with inSampleSize)
        val diskFile = diskPath(appCtx, id)
        loadFromDisk(appCtx, id)?.let { return it }
        // 3. System — with launcherInfo fallback (recovers after low-RAM kill)
        return try {
            val info = item.launcherInfo ?: resolveLauncherInfo(appCtx, item) ?: return null
            item.launcherInfo = info
            val drawable = info.getBadgedIcon(0)
            val targetPx = (64 * appCtx.resources.displayMetrics.density).toInt()
            val result = if (drawable.intrinsicWidth > targetPx || drawable.intrinsicHeight > targetPx) {
                val bmp = drawableToBitmap(drawable)
                val ratio = targetPx.toFloat() / maxOf(bmp.width, bmp.height)
                val nw = (bmp.width * ratio).toInt().coerceAtLeast(1)
                val nh = (bmp.height * ratio).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(bmp, nw, nh, true)
                saveToDisk(diskFile, scaled); BitmapDrawable(appCtx.resources, scaled)
            } else {
                saveToDisk(diskFile, drawableToBitmap(drawable)); drawable
            }
            memCache.put(id, result); result
        } catch (_: Throwable) { null }
    }

    /** Recover LauncherActivityInfo after cold-start / low-RAM kill (JSON has no launcherInfo). */
    private fun resolveLauncherInfo(ctx: Context, item: AppItem) = try {
        val la = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as? LauncherApps
        var found: android.content.pm.LauncherActivityInfo? = null
        if (la != null) {
            val users = linkedSetOf<UserHandle>()
            resolveUserHandle(ctx, item)?.let { users.add(it) }
            users.add(item.user)
            users.add(Process.myUserHandle())
            for (user in users) {
                val list = try { la.getActivityList(item.packageName, user) } catch (_: Throwable) { continue }
                found = list.firstOrNull { it.componentName.className == item.componentName }
                if (found != null) break
            }
        }
        found
    } catch (_: Throwable) { null }

    private fun resolveUserHandle(ctx: Context, item: AppItem): UserHandle? {
        return try {
            val um = ctx.getSystemService(Context.USER_SERVICE) as? UserManager
            um?.getUserForSerialNumber(item.userSerial) ?: item.user
        } catch (_: Throwable) { item.user }
    }

    private fun loadFromDisk(appCtx: Context, id: String): Drawable? {
        memCache.get(id)?.let { return it }
        val diskFile = diskPath(appCtx, id)
        if (!diskFile.exists()) return null
        return try {
            val targetPx = (64 * appCtx.resources.displayMetrics.density).toInt()
            val opts = BitmapFactory.Options().apply {
                inSampleSize = computeSampleSize(diskFile.absolutePath, targetPx)
            }
            val bmp = BitmapFactory.decodeFile(diskFile.absolutePath, opts)
            if (bmp != null) BitmapDrawable(appCtx.resources, bmp).also { memCache.put(id, it) } else null
        } catch (_: Throwable) { null }
    }

    private fun computeSampleSize(path: String, targetPx: Int): Int {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, opts)
            var sample = 1
            val hw = maxOf(opts.outWidth, opts.outHeight)
            if (hw <= 0 || targetPx <= 0) return 1
            while (hw / sample > targetPx * 2) sample *= 2
            sample
        } catch (_: Throwable) { 1 }
    }

    private fun drawableToBitmap(d: Drawable): Bitmap {
        if (d is BitmapDrawable) { val b = d.bitmap; if (b != null) return b }
        val w = d.intrinsicWidth.coerceAtLeast(1); val h = d.intrinsicHeight.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bmp); d.setBounds(0, 0, w, h); d.draw(c); return bmp
    }

    private fun diskPath(ctx: Context, id: String): File {
        val safe = id.replace(Regex("[^a-zA-Z0-9_.-]"), "_")
        return File(ctx.cacheDir, "icons/$safe.png").also { it.parentFile?.mkdirs() }
    }

    private fun saveToDisk(file: File, bmp: Bitmap) {
        try { FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 80, it) } } catch (_: Throwable) {}
    }

    fun clearDisk(ctx: Context) {
        try { File(ctx.cacheDir, "icons").deleteRecursively() } catch (_: Throwable) {}
    }

    private class PriorityRunnable(val priority: Int, private val block: () -> Unit) : Runnable, Comparable<PriorityRunnable> {
        val seq = nextSeq()
        override fun run() = block()
        override fun compareTo(other: PriorityRunnable): Int {
            val c = priority.compareTo(other.priority); return if (c != 0) c else seq.compareTo(other.seq)
        }
        companion object {
            private var counter = java.util.concurrent.atomic.AtomicLong(0)
            private fun nextSeq() = counter.incrementAndGet()
        }
    }
}
