package com.homelauncher.prime.util

import android.content.Context
import androidx.preference.PreferenceManager
import java.net.HttpURLConnection
import java.net.URL

object PublicIp {
    @Volatile private var cached: String? = null
    @Volatile private var lastFetch: Long = 0
    private const val TTL_MS = 5 * 60_000L // 5 minutes

    /** Returns the cached IP immediately (may be null) and refreshes in background. */
    fun getCached(): String? = cached

    /**
     * Blocking fetch of public IP. Call on IO thread. Result cached for TTL_MS.
     * Tries multiple providers so we don't fail on a single outage.
     */
    fun fetchBlocking(): String? {
        val now = System.currentTimeMillis()
        val c = cached
        if (c != null && now - lastFetch < TTL_MS) return c
        val urls = listOf(
            "https://api.ipify.org",
            "https://ifconfig.me/ip",
            "https://icanhazip.com"
        )
        for (u in urls) {
            try {
                val conn = URL(u).openConnection() as HttpURLConnection
                conn.connectTimeout = 4000; conn.readTimeout = 4000
                conn.requestMethod = "GET"
                conn.setRequestProperty("User-Agent", "HomeLauncher")
                if (conn.responseCode in 200..299) {
                    val text = conn.inputStream.bufferedReader().use { it.readText() }.trim()
                    if (text.isNotEmpty() && text.length < 64) {
                        cached = text; lastFetch = now
                        return text
                    }
                }
            } catch (_: Throwable) {}
        }
        return cached
    }
}
