package com.homelauncher.prime.ui

import android.content.Context
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.homelauncher.prime.R
import com.homelauncher.prime.data.AppItem
import com.homelauncher.prime.util.IconCache

/** Mixed adapter: shortcuts (single apps) + folders (group of apps). */

    private fun applyIconShape(ctx: android.content.Context, icon: android.widget.ImageView) {
        val shape = androidx.preference.PreferenceManager.getDefaultSharedPreferences(ctx)
            .getString("icon_shape", "rounded") ?: "rounded"
        val radius = when (shape) {
            "circle" -> 999f
            "squircle" -> 24f
            "teardrop" -> 22f
            "square" -> 4f
            else -> 18f // rounded default
        }
        icon.clipToOutline = true
        icon.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                val r = (radius * view.resources.displayMetrics.density).toInt()
                outline.setRoundRect(0, 0, view.width, view.height, r.toFloat())
            }
        }
    }


    private fun getLabelColor(ctx: android.content.Context): Int {
        val colorStr = androidx.preference.PreferenceManager.getDefaultSharedPreferences(ctx)
            .getString("app_label_color", "#FFFFFF") ?: "#FFFFFF"
        return try { android.graphics.Color.parseColor(colorStr) } catch (_: Throwable) { android.graphics.Color.WHITE }
    }

    private fun getLabelFontSizeSp(ctx: android.content.Context): Float {
        return androidx.preference.PreferenceManager.getDefaultSharedPreferences(ctx)
            .getInt("label_font_size", 11).coerceIn(8, 18).toFloat()
    }

class DesktopAdapter(
    val entries: MutableList<Entry>,
    private val onAppClick: (AppItem, View) -> Unit,
    private val onAppLongClick: (AppItem, View, () -> Unit) -> Unit,
    private val onFolderLongClick: ((String, List<AppItem>, View, () -> Unit) -> Unit)? = null,
    private val locked: Boolean = true,
    private val onStartDrag: ((RecyclerView.ViewHolder) -> Unit)? = null
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    sealed class Entry {
        data class Shortcut(val app: AppItem) : Entry()
        data class Folder(val name: String, val apps: List<AppItem>) : Entry()
    }

    fun keyOf(e: Entry): String = when (e) {
        is Entry.Shortcut -> "S:${e.app.id}"
        is Entry.Folder -> "F:${e.name}"
    }

    fun snapshotKeys(): List<String> = entries.map { keyOf(it) }

    fun moveItem(from: Int, to: Int) {
        if (from == to || from !in entries.indices || to !in entries.indices) return
        val item = entries.removeAt(from)
        entries.add(to, item)
        notifyItemMoved(from, to)
    }

    private val TYPE_SHORTCUT = 0
    private val TYPE_FOLDER = 1

    override fun getItemViewType(position: Int): Int = when (entries[position]) {
        is Entry.Shortcut -> TYPE_SHORTCUT
        is Entry.Folder -> TYPE_FOLDER
    }

    override fun getItemCount(): Int = entries.size

    class ShortcutVH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    class FolderVH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.folderTitle)
        val preview: GridLayout = v.findViewById(R.id.folderPreview)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_SHORTCUT)
            ShortcutVH(inflater.inflate(R.layout.item_app, parent, false))
        else
            FolderVH(inflater.inflate(R.layout.item_folder, parent, false))
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
        when (val e = entries[pos]) {
            is Entry.Shortcut -> {
                val vh = h as ShortcutVH
                val px = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, 56f,
                    h.itemView.resources.displayMetrics
                ).toInt()
                vh.icon.layoutParams = vh.icon.layoutParams.apply { width = px; height = px }
                IconCache.load(vh.itemView.context, e.app, vh.icon); applyIconShape(vh.itemView.context, vh.icon)
                vh.label.text = e.app.label
            vh.label.setTextColor(getLabelColor(vh.itemView.context))
            vh.label.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, getLabelFontSizeSp(vh.itemView.context))
            val tf = com.homelauncher.prime.util.FontManager.getCurrentTypeface(vh.itemView.context)
            if (tf != android.graphics.Typeface.DEFAULT) vh.label.typeface = tf
                // Notification badge — find or create overlay
                val badgeKey = 12345; var badge = vh.itemView.getTag(badgeKey) as? TextView
                val badgeCount = NotificationListener.getBadgeCount(
                    h.itemView.context.getSharedPreferences("notification_badges", Context.MODE_PRIVATE),
                    e.app.packageName
                )
                if (badgeCount > 0) {
                    if (badge == null) {
                        val ctx = h.itemView.context
                        val d = (16f * ctx.resources.displayMetrics.density).toInt()
                        badge = TextView(ctx).apply {
                            setTextColor(android.graphics.Color.WHITE); setTextSize(10f)
                            gravity = android.view.Gravity.CENTER
                            background = android.graphics.drawable.GradientDrawable().apply {
                                shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(0xFFFF3B30.toInt())
                            }
                            layoutParams = ViewGroup.LayoutParams(d, d)
                        }
                        (vh.itemView as ViewGroup).addView(badge)
                        vh.itemView.setTag(badgeKey, badge)
                    }
                    badge.text = if (badgeCount > 99) "99+" else badgeCount.toString()
                    badge.visibility = View.VISIBLE
                    badge.post {
                        val lp = badge.layoutParams as ViewGroup.MarginLayoutParams
                        lp.topMargin = vh.icon.top
                        val marginEnd = vh.icon.width - badge.width + (2f * vh.itemView.resources.displayMetrics.density).toInt()
                        lp.marginStart = vh.icon.left + vh.icon.width - badge.width / 2
                        badge.layoutParams = lp
                    }
                } else {
                    badge?.visibility = View.GONE
                }
                vh.itemView.setOnClickListener { onAppClick(e.app, vh.itemView) }
                vh.itemView.setOnLongClickListener {
                    val startMove: () -> Unit = { onStartDrag?.invoke(vh) }
                    onAppLongClick(e.app, vh.itemView, startMove)
                    true
                }
            }
            is Entry.Folder -> {
                val vh = h as FolderVH
                val ctx: Context = vh.itemView.context
                vh.title.text = e.name
                vh.title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, getLabelFontSizeSp(ctx))
                vh.title.setTextColor(getLabelColor(ctx))
                val tf2 = com.homelauncher.prime.util.FontManager.getCurrentTypeface(ctx)
                if (tf2 != android.graphics.Typeface.DEFAULT) vh.title.typeface = tf2
                vh.preview.removeAllViews()
                e.apps.take(6).forEach { app ->
                    val iv = ImageView(ctx)
                    val lp = GridLayout.LayoutParams().apply {
                        width = 0; height = 0
                        columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                        rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                        setMargins(2, 2, 2, 2)
                    }
                    iv.layoutParams = lp
                    iv.scaleType = ImageView.ScaleType.FIT_CENTER
                    IconCache.load(ctx, app, iv)
                    vh.preview.addView(iv)
                }
                vh.itemView.setOnClickListener {
                    FolderPopup.show(ctx, e.name, e.apps, onAppClick) { item, v ->
                        // Folder member long-press: just show its menu (no move handle here).
                        onAppLongClick(item, v) {}
                    }
                }
                vh.itemView.setOnLongClickListener {
                    val startMove: () -> Unit = { onStartDrag?.invoke(vh) }
                    if (onFolderLongClick != null) {
                        onFolderLongClick.invoke(e.name, e.apps, vh.itemView, startMove)
                    } else {
                        FolderPopup.show(ctx, e.name, e.apps, onAppClick) { item, v ->
                            onAppLongClick(item, v) {}
                        }
                    }
                    true
                }
            }
        }
    }
}
