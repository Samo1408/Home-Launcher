package com.homelauncher.prime.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object DesktopStore {
    // In-memory cache to avoid JSON parsing on every render
    @Volatile private var memPages: List<List<String>>? = null
    @Volatile private var memShortcuts: Set<String>? = null
    @Volatile private var memFolders: LinkedHashMap<String, MutableList<String>>? = null
    private var lastWriteTime = 0L

    fun clearMemCache() { memPages = null; memShortcuts = null; memFolders = null }
    private const val FILE = "desktop_layout"
    private const val KEY_SHORTCUTS = "shortcut_ids"
    private const val KEY_FOLDERS = "folders_json"
    private const val KEY_WIDGETS = "widgets_csv"
    private const val KEY_DESKTOP_ORDER = "desktop_order_json"
    private const val KEY_DESKTOP_PAGES = "desktop_pages_json" // [["S:id","F:name"], ...]

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---- Multi-page desktop ----
    fun getDesktopPages(ctx: Context): List<List<String>> {
        memPages?.let { return it }
        val raw = prefs(ctx).getString(KEY_DESKTOP_PAGES, null)
        if (raw != null) return try {
            val arr = JSONArray(raw); val out = ArrayList<List<String>>()
            for (i in 0 until arr.length()) {
                val pageArr = arr.getJSONArray(i); val page = ArrayList<String>()
                for (j in 0 until pageArr.length()) page += pageArr.getString(j)
                out += page
            }
            out.ifEmpty { listOf(emptyList<String>()) }.also { memPages = it }
        } catch (_: Throwable) { listOf(emptyList<String>()) }

        // Migrate old single-page order
        val old = getDesktopOrder(ctx)
        if (old.isNotEmpty()) { saveDesktopPages(ctx, listOf(old)); return listOf(old) }
        return listOf(emptyList<String>())
    }

    fun saveDesktopPages(ctx: Context, pages: List<List<String>>) {
        val arr = JSONArray()
        for (page in pages) { val pArr = JSONArray(); for (k in page) pArr.put(k); arr.put(pArr) }
        prefs(ctx).edit().putString(KEY_DESKTOP_PAGES, arr.toString()).apply()
        memPages = pages
    }

    fun addDesktopPage(ctx: Context, afterIndex: Int): List<List<String>> {
        val pages = getDesktopPages(ctx).toMutableList()
        pages.add(afterIndex + 1, emptyList<String>())
        saveDesktopPages(ctx, pages)
        return pages
    }

    fun removeDesktopPage(ctx: Context, pageIndex: Int): List<List<String>> {
        val pages = getDesktopPages(ctx).toMutableList()
        if (pages.size <= 1) return pages
        pages.removeAt(pageIndex.coerceIn(0, pages.size - 1))
        saveDesktopPages(ctx, pages)
        return pages
    }

    fun moveToPage(ctx: Context, entryKey: String, fromPage: Int, toPage: Int) {
        val pages = getDesktopPages(ctx).map { it.toMutableList() }.toMutableList()
        if (fromPage in pages.indices && toPage in pages.indices) {
            pages[fromPage].remove(entryKey)
            pages[toPage].add(entryKey)
            saveDesktopPages(ctx, pages)
        }
    }

    // ---- Legacy single-page (kept for backward compat) ----
    fun getDesktopOrder(ctx: Context): List<String> {
        val raw = prefs(ctx).getString(KEY_DESKTOP_ORDER, null) ?: return emptyList()
        return try { val arr = JSONArray(raw); (0 until arr.length()).map { arr.getString(it) } } catch (_: Throwable) { emptyList() }
    }

    fun saveDesktopOrder(ctx: Context, list: List<String>) {
        prefs(ctx).edit().putString(KEY_DESKTOP_ORDER, JSONArray(list).toString()).apply()
    }

    // ---- Shortcuts ----
    fun getShortcutIds(ctx: Context): Set<String> {
        memShortcuts?.let { return it }
        return (prefs(ctx).getStringSet(KEY_SHORTCUTS, emptySet()) ?: emptySet()).also { memShortcuts = it }
    }
    fun addShortcut(ctx: Context, id: String) {
        val cur = getShortcutIds(ctx).toMutableSet().also { it += id }
        prefs(ctx).edit().putStringSet(KEY_SHORTCUTS, cur).apply(); memShortcuts = cur
    }
    fun removeShortcut(ctx: Context, id: String) {
        val cur = getShortcutIds(ctx).toMutableSet().also { it -= id }
        prefs(ctx).edit().putStringSet(KEY_SHORTCUTS, cur).apply(); memShortcuts = cur
    }
    fun clearShortcuts(ctx: Context) { prefs(ctx).edit().remove(KEY_SHORTCUTS).apply(); memShortcuts = emptySet() }

    // ---- Folders ----
    fun getFolders(ctx: Context): LinkedHashMap<String, MutableList<String>> {
        memFolders?.let { return it }
        val raw = prefs(ctx).getString(KEY_FOLDERS, null) ?: return LinkedHashMap()
        return try {
            val obj = JSONObject(raw); val out = LinkedHashMap<String, MutableList<String>>()
            obj.keys().forEach { k -> val ids = mutableListOf<String>(); val arr = obj.getJSONArray(k); for (i in 0 until arr.length()) ids += arr.getString(i); out[k] = ids }
            out
        } catch (_: Throwable) { LinkedHashMap() }.also { memFolders = it }
    }

    fun saveFolders(ctx: Context, map: Map<String, List<String>>) {
        memFolders = LinkedHashMap(map.mapValues { it.value.toMutableList() })
        val obj = JSONObject(); for ((k, v) in map) obj.put(k, JSONArray(v)); prefs(ctx).edit().putString(KEY_FOLDERS, obj.toString()).apply()
    }

    fun addAppsToFolder(ctx: Context, folderName: String, ids: Collection<String>) {
        val map = getFolders(ctx); for ((_, list) in map) list.removeAll(ids.toSet())
        val target = map.getOrPut(folderName) { mutableListOf() }; for (id in ids) if (!target.contains(id)) target += id
        saveFolders(ctx, map)
    }

    fun removeAppFromFolder(ctx: Context, folderName: String, id: String) {
        val map = getFolders(ctx); map[folderName]?.remove(id); if (map[folderName]?.isEmpty() == true) map.remove(folderName); saveFolders(ctx, map)
    }

    fun deleteFolder(ctx: Context, folderName: String) { val map = getFolders(ctx); map.remove(folderName); saveFolders(ctx, map) }
    fun renameFolder(ctx: Context, oldName: String, newName: String) {
        if (oldName == newName) return; val map = getFolders(ctx); val v = map.remove(oldName) ?: return; map[newName] = v; saveFolders(ctx, map)
    }

    fun appIdToFolder(ctx: Context): Map<String, String> {
        val out = HashMap<String, String>(); for ((name, ids) in getFolders(ctx)) for (id in ids) out[id] = name; return out
    }

    // ---- Widgets ----
    fun getWidgetIds(ctx: Context): List<Int> = prefs(ctx).getString(KEY_WIDGETS, "")?.split(',')?.mapNotNull { it.trim().toIntOrNull() } ?: emptyList()
    fun addWidget(ctx: Context, id: Int) { val cur = getWidgetIds(ctx).toMutableList(); if (!cur.contains(id)) cur += id; prefs(ctx).edit().putString(KEY_WIDGETS, cur.joinToString(",")).apply() }
    fun removeWidget(ctx: Context, id: Int) { val cur = getWidgetIds(ctx).toMutableList().also { it.remove(id) }; prefs(ctx).edit().putString(KEY_WIDGETS, cur.joinToString(",")).apply() }
    fun resetAll(ctx: Context) { prefs(ctx).edit().clear().apply(); clearMemCache() }

    // ---- Export / Import ----

    fun exportAll(ctx: Context, file: java.io.File) {
        val root = org.json.JSONObject()
        // Desktop layout (multi-page)
        root.put(KEY_DESKTOP_PAGES, org.json.JSONArray().apply {
            for (page in getDesktopPages(ctx)) {
                put(org.json.JSONArray().apply { for (k in page) put(k) })
            }
        })
        // Shortcuts
        root.put(KEY_SHORTCUTS, org.json.JSONArray().apply {
            for (id in getShortcutIds(ctx)) put(id)
        })
        // Folders
        val foldersObj = org.json.JSONObject()
        for ((name, ids) in getFolders(ctx)) {
            foldersObj.put(name, org.json.JSONArray().apply { for (id in ids) put(id) })
        }
        root.put(KEY_FOLDERS, foldersObj)
        // Widgets
        root.put(KEY_WIDGETS, org.json.JSONArray().apply {
            for (id in getWidgetIds(ctx)) put(id)
        })
        file.writeText(root.toString(2))
    }

    fun importAll(ctx: Context, file: java.io.File) {
        val root = org.json.JSONObject(file.readText())
        // Desktop pages
        if (root.has(KEY_DESKTOP_PAGES)) {
            val arr = root.getJSONArray(KEY_DESKTOP_PAGES)
            val pages = mutableListOf<List<String>>()
            for (i in 0 until arr.length()) {
                val pArr = arr.getJSONArray(i)
                val page = mutableListOf<String>()
                for (j in 0 until pArr.length()) page += pArr.getString(j)
                pages += page
            }
            if (pages.isNotEmpty()) saveDesktopPages(ctx, pages)
        }
        // Shortcuts
        if (root.has(KEY_SHORTCUTS)) {
            val arr = root.getJSONArray(KEY_SHORTCUTS)
            val ids = mutableSetOf<String>()
            for (i in 0 until arr.length()) ids += arr.getString(i)
            ctx.getSharedPreferences("desktop_layout", android.content.Context.MODE_PRIVATE)
                .edit().putStringSet(KEY_SHORTCUTS, ids).apply()
        }
        // Folders
        if (root.has(KEY_FOLDERS)) {
            val obj = root.getJSONObject(KEY_FOLDERS)
            val map = LinkedHashMap<String, MutableList<String>>()
            obj.keys().forEach { k ->
                val fArr = obj.getJSONArray(k)
                map[k] = (0 until fArr.length()).map { fArr.getString(it) }.toMutableList()
            }
            saveFolders(ctx, map)
        }
        // Widgets
        if (root.has(KEY_WIDGETS)) {
            val wArr = root.getJSONArray(KEY_WIDGETS)
            val wIds = (0 until wArr.length()).map { wArr.getInt(it) }.joinToString(",")
            ctx.getSharedPreferences("desktop_layout", android.content.Context.MODE_PRIVATE)
                .edit().putString(KEY_WIDGETS, wIds).apply()
        }
    }

}
