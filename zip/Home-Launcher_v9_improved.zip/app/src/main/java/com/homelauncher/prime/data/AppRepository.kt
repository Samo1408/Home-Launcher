package com.homelauncher.prime.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.LauncherApps
import android.os.Process
import android.os.UserManager
import com.homelauncher.prime.util.IconCache
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object AppRepository {
    private const val CACHE_FILE = "apps_cache.json"
    private const val CACHE_META = "apps_cache_meta.json"

    @Volatile private var cache: List<AppItem>? = null
    @Volatile var dirty: Boolean = true
        private set
    @Volatile var initialLoadComplete: Boolean = false
        private set
    @Volatile private var hydrated: Boolean = false

    private var receiverRegistered = false
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    fun cached(): List<AppItem>? = cache

    fun invalidate() { dirty = true; cache = null; initialLoadComplete = false; hydrated = false }

    /**
     * Show cached data instantly (even if dirty), refresh in background,
     * hydrate launcherInfo from PackageManager after cold-start.
     */
    fun loadFast(context: Context): List<AppItem> {
        val file = File(context.filesDir, CACHE_FILE)
        if (cache == null && file.exists()) {
            cache = deserialize(context, file)
            // Treat as valid temporarily so UI shows data instead of an empty screen
            if (cache != null) dirty = false
        }
        cache?.let { IconCache.prefetchAll(context, it, priority = 12, limit = 160) }
        // Refresh in background if we've never done a full load
        if (cache == null || !initialLoadComplete) {
            scope.launch { loadAll(context) }
        }
        // Restore launcherInfo for items loaded from JSON (post cold-start)
        if (cache != null && !hydrated) {
            scope.launch { hydrateLauncherInfo(context) }
        }
        return cache ?: emptyList()
    }

    /** Rebind LauncherActivityInfo for cached items (JSON dropped it as @Transient). */
    fun hydrateLauncherInfo(context: Context) {
        val apps = cache ?: return
        try {
            val launcher = context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
            val um = context.getSystemService(Context.USER_SERVICE) as UserManager
            val byPkg = apps.groupBy { it.packageName }
            for ((pkg, items) in byPkg) {
                val user = um.getUserForSerialNumber(items.first().userSerial) ?: items.first().user
                val activityList = try { launcher.getActivityList(pkg, user) } catch (_: Throwable) { continue }
                for (item in items) {
                    if (item.launcherInfo == null) {
                        item.launcherInfo = activityList.firstOrNull {
                            it.componentName.className == item.componentName
                        }
                    }
                }
            }
            hydrated = true
        } catch (_: Throwable) {}
    }

    fun loadAll(context: Context): List<AppItem> {
        val launcher = context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        val um = context.getSystemService(Context.USER_SERVICE) as UserManager
        val myUser = Process.myUserHandle()
        val out = ArrayList<AppItem>(256)

        for (user in um.userProfiles) {
            val isWork = user != myUser
            val serial = um.getSerialNumberForUser(user)
            val userLabel = if (isWork) "user $serial" else "Personal"
            for (info in launcher.getActivityList(null, user)) {
                out += AppItem(
                    packageName = info.applicationInfo.packageName,
                    componentName = info.componentName.className,
                    label = info.label?.toString() ?: info.applicationInfo.packageName,
                    user = user,
                    userSerial = serial,
                    isWork = isWork,
                    userLabel = userLabel
                ).also { it.launcherInfo = info }
            }
        }
        out.sortWith(compareBy { it.label.lowercase() })
        IconCache.prefetchAll(context, out, priority = 8, limit = 220)
        cache = out
        dirty = false
        initialLoadComplete = true
        hydrated = true
        // Persist to file for fast cold start
        scope.launch { serialize(context, out) }
        return out
    }

    fun registerPackageListener(context: Context) {
        if (receiverRegistered) return
        receiverRegistered = true
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        context.registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                invalidate()
            }
        }, filter)
    }

    fun groupByUser(apps: List<AppItem>): Map<String, List<AppItem>> =
        apps.groupBy { it.userLabel }

    // ── Serialization ──
    private fun serialize(ctx: Context, list: List<AppItem>) {
        try {
            val arr = JSONArray()
            for (a in list) {
                arr.put(JSONObject().apply {
                    put("pkg", a.packageName)
                    put("cls", a.componentName)
                    put("label", a.label)
                    put("serial", a.userSerial)
                    put("work", a.isWork)
                    put("ulabel", a.userLabel)
                })
            }
            File(ctx.filesDir, CACHE_FILE).writeText(arr.toString())
            val meta = JSONObject().apply {
                put("count", list.size)
                put("time", System.currentTimeMillis())
            }
            File(ctx.filesDir, CACHE_META).writeText(meta.toString())
        } catch (_: Throwable) {}
    }

    private fun deserialize(ctx: Context, file: File): List<AppItem>? = try {
        val um = ctx.getSystemService(Context.USER_SERVICE) as UserManager
        val arr = JSONArray(file.readText())
        val out = ArrayList<AppItem>(arr.length())
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val serial = obj.getLong("serial")
            out += AppItem(
                packageName = obj.getString("pkg"),
                componentName = obj.getString("cls"),
                label = obj.getString("label"),
                user = um.getUserForSerialNumber(serial) ?: Process.myUserHandle(),
                userSerial = serial,
                isWork = obj.getBoolean("work"),
                userLabel = obj.getString("ulabel")
            )
        }
        out
    } catch (_: Throwable) { null }
}
