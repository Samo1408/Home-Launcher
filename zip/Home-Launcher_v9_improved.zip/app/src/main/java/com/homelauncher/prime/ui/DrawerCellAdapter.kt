package com.homelauncher.prime.ui

import android.content.Context
import android.graphics.Color
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.homelauncher.prime.R
import com.homelauncher.prime.data.AppItem
import com.homelauncher.prime.util.IconCache


    private fun applyIconShape(ctx: android.content.Context, icon: android.widget.ImageView) {
        val shape = androidx.preference.PreferenceManager.getDefaultSharedPreferences(ctx)
            .getString("icon_shape", "rounded") ?: "rounded"
        val radius = when (shape) {
            "circle" -> 999f
            "squircle" -> 24f
            "teardrop" -> 22f
            "square" -> 4f
            else -> 18f // rounded default
        }
        icon.clipToOutline = true
        icon.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                val r = (radius * view.resources.displayMetrics.density).toInt()
                outline.setRoundRect(0, 0, view.width, view.height, r.toFloat())
            }
        }
    }


    private fun getLabelColor(ctx: android.content.Context): Int {
        val colorStr = androidx.preference.PreferenceManager.getDefaultSharedPreferences(ctx)
            .getString("app_label_color", "#FFFFFF") ?: "#FFFFFF"
        return try { android.graphics.Color.parseColor(colorStr) } catch (_: Throwable) { android.graphics.Color.WHITE }
    }

    private fun getLabelFontSizeSp(ctx: android.content.Context): Float {
        return androidx.preference.PreferenceManager.getDefaultSharedPreferences(ctx)
            .getInt("label_font_size", 11).coerceIn(8, 18).toFloat()
    }

class DrawerCellAdapter(
    private val entries: MutableList<DrawerEntry>,
    private val iconSizeDp: Int,
    private val onAppClick: (AppItem, View) -> Unit,
    private val onAppLongClick: (AppItem, View) -> Unit,
    private val onFolderLongClick: (String, View) -> Unit,
    private val selection: SelectionState? = null
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    class SelectionState {
        var active: Boolean = false
        val ids: MutableSet<String> = LinkedHashSet()
        var onChanged: (() -> Unit)? = null
        fun toggle(id: String) { if (!ids.add(id)) ids.remove(id); onChanged?.invoke() }
        fun clear() { ids.clear(); onChanged?.invoke() }
    }

    private val TYPE_APP = 0; private val TYPE_FOLDER = 1
    override fun getItemViewType(position: Int) = when (entries[position]) { is DrawerEntry.App -> TYPE_APP; is DrawerEntry.Folder -> TYPE_FOLDER }
    override fun getItemCount() = entries.size

    class AppVH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
        val badge: TextView = android.widget.TextView(v.context).apply {
            setTextColor(android.graphics.Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            gravity = android.view.Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(0xFFFF3B30.toInt())
            }
            val dp6 = (6 * v.resources.displayMetrics.density).toInt()
            setPadding(dp6, dp6/2, dp6, dp6/2); visibility = View.GONE; minWidth = dp6 * 3
            (v as ViewGroup).addView(this)
        }
    }
    class FolderVH(v: View) : RecyclerView.ViewHolder(v) { val title: TextView = v.findViewById(R.id.folderTitle); val preview: GridLayout = v.findViewById(R.id.folderPreview) }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_APP) AppVH(inflater.inflate(R.layout.item_app, parent, false))
        else FolderVH(inflater.inflate(R.layout.item_folder, parent, false))
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
        when (val e = entries[pos]) {
            is DrawerEntry.App -> {
                val vh = h as AppVH
                val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, iconSizeDp.toFloat(), h.itemView.resources.displayMetrics).toInt()
                vh.icon.layoutParams = vh.icon.layoutParams.apply { width = px; height = px }
                IconCache.load(vh.itemView.context, e.app, vh.icon); applyIconShape(vh.itemView.context, vh.icon)
                vh.label.text = e.app.label
            vh.label.setTextColor(getLabelColor(vh.itemView.context))
            vh.label.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, getLabelFontSizeSp(vh.itemView.context))
            val tf = com.homelauncher.prime.util.FontManager.getCurrentTypeface(vh.itemView.context)
            if (tf != android.graphics.Typeface.DEFAULT) vh.label.typeface = tf
                // Notification badge
                val badgeCount = NotificationListener.getBadgeCount(
                    h.itemView.context.getSharedPreferences("notification_badges", android.content.Context.MODE_PRIVATE),
                    e.app.packageName
                )
                if (badgeCount > 0) {
                    vh.badge.text = if (badgeCount > 99) "99+" else badgeCount.toString()
                    vh.badge.visibility = View.VISIBLE
                } else { vh.badge.visibility = View.GONE }
                val sel = selection; val isSelected = sel != null && sel.active && sel.ids.contains(e.app.id)
                vh.itemView.setBackgroundColor(if (isSelected) 0x553B82F6 else Color.TRANSPARENT)
                vh.itemView.alpha = if (sel != null && sel.active && !isSelected) 0.7f else 1f
                vh.itemView.setOnClickListener { view ->
                    if (sel != null && sel.active) { sel.toggle(e.app.id); notifyItemChanged(pos) }
                    else pressAnim(view) { onAppClick(e.app, view) }
                }
                vh.itemView.setOnLongClickListener {
                    if (sel != null && sel.active) { sel.toggle(e.app.id); notifyItemChanged(pos) } else onAppLongClick(e.app, vh.itemView); true
                }
                if (vh.itemView.scaleX == 1f && vh.itemView.tag == null) {
                    vh.itemView.tag = true; vh.itemView.scaleX = 0.6f; vh.itemView.scaleY = 0.6f; vh.itemView.alpha = 0f
                    vh.itemView.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(280).setInterpolator(OvershootInterpolator(0.6f)).start()
                }
            }
            is DrawerEntry.Folder -> {
                val vh = h as FolderVH; val ctx = vh.itemView.context
                vh.title.text = e.name
                vh.title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, getLabelFontSizeSp(ctx))
                vh.title.setTextColor(getLabelColor(ctx))
                val tfF = com.homelauncher.prime.util.FontManager.getCurrentTypeface(ctx)
                if (tfF != android.graphics.Typeface.DEFAULT) vh.title.typeface = tfF
                val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, iconSizeDp.toFloat(), h.itemView.resources.displayMetrics).toInt()
                vh.itemView.findViewById<View>(R.id.folderFrame)?.let { fr -> fr.layoutParams = fr.layoutParams.apply { width = px; height = px } }
                vh.preview.removeAllViews()
                e.apps.take(4).forEach { app ->
                    val iv = ImageView(ctx)
                    iv.layoutParams = GridLayout.LayoutParams().apply {
                        width = 0; height = 0; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(2, 2, 2, 2)
                    }
                    iv.scaleType = ImageView.ScaleType.FIT_CENTER; IconCache.load(ctx, app, iv); vh.preview.addView(iv)
                }
                val sel = selection; vh.itemView.alpha = if (sel != null && sel.active) 0.5f else 1f
                vh.itemView.setOnClickListener { view -> if (sel != null && sel.active) return@setOnClickListener; pressAnim(view) { FolderPopup.show(ctx, e.name, e.apps, onAppClick, onAppLongClick) } }
                vh.itemView.setOnLongClickListener { if (sel == null || !sel.active) onFolderLongClick(e.name, vh.itemView); true }
            }
        }
    }

    private fun pressAnim(view: View, onEnd: () -> Unit) {
        view.animate().cancel()
        view.animate().scaleX(0.90f).scaleY(0.90f).setDuration(65).withEndAction {
            view.animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(OvershootInterpolator(0.5f)).withEndAction { onEnd() }.start()
        }.start()
    }

    fun submit(list: List<DrawerEntry>) { entries.clear(); entries.addAll(list); notifyDataSetChanged() }
    fun moveItem(from: Int, to: Int) {
        if (from == to || from !in entries.indices || to !in entries.indices) return
        val item = entries.removeAt(from); entries.add(to, item); notifyItemMoved(from, to)
    }
}
