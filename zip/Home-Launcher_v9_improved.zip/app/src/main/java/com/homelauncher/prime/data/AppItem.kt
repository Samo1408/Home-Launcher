package com.homelauncher.prime.data

import android.content.pm.LauncherActivityInfo
import android.os.UserHandle

/**
 * Lightweight app entry. The icon is NOT held here — icons are loaded
 * lazily through IconCache so cold start / drawer open does not block
 * the main thread or hold hundreds of bitmaps in memory at once.
 */
data class AppItem(
    val packageName: String,
    val componentName: String,
    val label: String,
    val user: UserHandle,
    val userSerial: Long,
    val isWork: Boolean,
    val userLabel: String // e.g. "Personal" or "user 10"
) {
    /**
     * Optional handle for fast icon resolution. Not part of equals/hashCode/copy
     * (declared in class body, not in primary constructor). May be null if the
     * item was re-built from cache without a backing LauncherActivityInfo.
     */
    @Transient var launcherInfo: LauncherActivityInfo? = null

    val id: String get() = "$packageName/$componentName@$userSerial"
}
