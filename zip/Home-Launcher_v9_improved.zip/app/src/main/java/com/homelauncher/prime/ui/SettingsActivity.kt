package com.homelauncher.prime.ui

import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.DialogPreference
import androidx.preference.PreferenceManager
import androidx.preference.SeekBarPreference
import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.widget.EditText
import android.widget.Toast
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.homelauncher.prime.R
import com.homelauncher.prime.util.DesktopStore
import com.homelauncher.prime.util.IntentUtil
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat


class SettingsActivity : AppCompatActivity() {
    private var alphaListener: SharedPreferences.OnSharedPreferenceChangeListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settings_container, SettingsFragment())
                .commit()
        }
        applyBackgroundAlpha()
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        alphaListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "settings_bg_alpha") applyBackgroundAlpha()
        }
        prefs.registerOnSharedPreferenceChangeListener(alphaListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        alphaListener?.let {
            PreferenceManager.getDefaultSharedPreferences(this)
                .unregisterOnSharedPreferenceChangeListener(it)
        }
    }

    private fun applyBackgroundAlpha() {
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        // 0..100 → alpha 0..255. Default 90 (mostly opaque, slight wallpaper bleed).
        val pct = prefs.getInt("settings_bg_alpha", 90).coerceIn(0, 100)
        val alpha = (pct * 255 / 100)
        // Base color: dark surface so text remains readable.
        val color = Color.argb(alpha, 0x12, 0x12, 0x12)
        window.setBackgroundDrawable(ColorDrawable(color))
        findViewById<View>(R.id.settings_container)?.setBackgroundColor(color)
    }

    class SettingsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)
            findPreference<ListPreference>("lock_method")?.apply {
                entries = arrayOf(getString(R.string.method_root), getString(R.string.method_admin))
                entryValues = arrayOf("root", "admin")
                if (value == null) value = "root"
            }
            findPreference<Preference>("enable_admin")?.setOnPreferenceClickListener {
                val ctx = requireContext()
                val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, IntentUtil.adminComponent(ctx))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Used for double-tap lock fallback.")
                startActivity(i); true
            }
                        findPreference<Preference>("export_settings")?.setOnPreferenceClickListener {
                val ctx = requireContext()
                val act = requireActivity()
                if (!checkStoragePermission(act)) { requestStoragePermission(act); return@setOnPreferenceClickListener true }
                val input = EditText(ctx).apply {
                    hint = "settings_backup.json"
                    setText("settings_backup")
                    inputType = android.text.InputType.TYPE_CLASS_TEXT
                }
                AlertDialog.Builder(ctx)
                    .setTitle("تسمية ملف النسخة الاحتياطية")
                    .setView(input)
                    .setPositiveButton("تصدير") { _, _ ->
                        try {
                            val name = input.text.toString().trim().ifEmpty { "settings_backup" }
                            val dir = java.io.File(Environment.getExternalStorageDirectory(), "HomeLauncher")
                            dir.mkdirs()
                            val file = java.io.File(dir, "${name}.json")
                            DesktopStore.exportAll(ctx, file)
                            Toast.makeText(ctx, "تم التصدير: ${file.absolutePath}", Toast.LENGTH_LONG).show()
                        } catch (e: Throwable) {
                            Toast.makeText(ctx, "فشل: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                    .setNegativeButton("إلغاء", null).show()
                true
            }
            findPreference<Preference>("select_font")?.setOnPreferenceClickListener {
                val ctx = requireContext()
                val fonts = com.homelauncher.prime.util.FontManager.getFontList()
                val fontNames = fonts.map { if (it.fileName.isEmpty()) it.name else "${it.name} ${if (com.homelauncher.prime.util.FontManager.isFontDownloaded(ctx, it)) "✓" else "⬇"}" }.toTypedArray()
                AlertDialog.Builder(ctx)
                    .setTitle("اختر الخط")
                    .setItems(fontNames) { _, which ->
                        val font = fonts[which]
                        if (font.fileName.isEmpty()) {
                            // Default — clear selection
                            androidx.preference.PreferenceManager.getDefaultSharedPreferences(ctx)
                                .edit().putString("selected_font_file", "").putString("selected_font_name", "الإفتراضي").apply()
                            AlertDialog.Builder(ctx)
                                .setTitle("تم")
                                .setMessage("تم اختيار الخط الإفتراضي. أعد تشغيل المشغل لتطبيقه.")
                                .setPositiveButton("حسناً", null).show()
                        } else if (com.homelauncher.prime.util.FontManager.isFontDownloaded(ctx, font)) {
                            // Already downloaded — apply
                            androidx.preference.PreferenceManager.getDefaultSharedPreferences(ctx)
                                .edit().putString("selected_font_file", font.fileName).putString("selected_font_name", font.name).apply()
                            AlertDialog.Builder(ctx)
                                .setTitle("تم")
                                .setMessage("تم اختيار خط ${font.name}. أعد تشغيل المشغل لتطبيقه.")
                                .setPositiveButton("حسناً", null).show()
                        } else {
                            // Need to download
                            val dlg = AlertDialog.Builder(ctx)
                                .setTitle("تحميل ${font.name}")
                                .setMessage("جارٍ تحميل الخط...")
                                .setCancelable(false).create()
                            dlg.show()
                            kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                                val ok = com.homelauncher.prime.util.FontManager.downloadFont(ctx, font)
                                dlg.dismiss()
                                if (ok) {
                                    androidx.preference.PreferenceManager.getDefaultSharedPreferences(ctx)
                                        .edit().putString("selected_font_file", font.fileName).putString("selected_font_name", font.name).apply()
                                    AlertDialog.Builder(ctx)
                                        .setTitle("تم التحميل")
                                        .setMessage("تم تحميل خط ${font.name} بنجاح. أعد تشغيل المشغل لتطبيقه.")
                                        .setPositiveButton("حسناً", null).show()
                                } else {
                                    AlertDialog.Builder(ctx)
                                        .setTitle("فشل التحميل")
                                        .setMessage("تعذر تحميل ${font.name}. تأكد من اتصال الإنترنت وحاول مجدداً.")
                                        .setPositiveButton("حسناً", null).show()
                                }
                            }
                        }
                    }
                    .setNegativeButton("إلغاء", null).show()
                true
            }
            findPreference<Preference>("restart_launcher")?.setOnPreferenceClickListener {
                AlertDialog.Builder(requireContext())
                    .setTitle("إعادة تشغيل المشغل")
                    .setMessage("هل تريد إعادة تشغيل المشغل الآن؟ سيتم تطبيق كافة الإعدادات الجديدة.")
                    .setPositiveButton("إعادة تشغيل") { _, _ ->
                        val act = requireActivity()
                        val pm = act.packageManager
                        val intent = pm.getLaunchIntentForPackage(act.packageName)
                        act.startActivity(android.content.Intent.makeRestartActivityTask(intent?.component))
                        Runtime.getRuntime().exit(0)
                    }
                    .setNegativeButton("إلغاء", null).show()
                true
            }
            findPreference<Preference>("import_settings")?.setOnPreferenceClickListener {
                val ctx = requireContext()
                val act = requireActivity()
                if (!checkStoragePermission(act)) { requestStoragePermission(act); return@setOnPreferenceClickListener true }
                val dir = java.io.File(Environment.getExternalStorageDirectory(), "HomeLauncher")
                dir.mkdirs()
                val files = dir.listFiles()?.filter { it.extension.equals("json", ignoreCase = true) }?.sortedByDescending { it.lastModified() } ?: emptyList()
                if (files.isEmpty()) {
                    Toast.makeText(ctx, "لا توجد نسخ احتياطية في: ${dir.absolutePath}", Toast.LENGTH_LONG).show()
                } else {
                    AlertDialog.Builder(ctx)
                        .setTitle("اختر نسخة لاستعادتها")
                        .setItems(files.map { "${it.name}  (${"%,d".format(it.length())} B)" }.toTypedArray()) { _, w ->
                            try {
                                DesktopStore.importAll(ctx, files[w])
                                Toast.makeText(ctx, "تم الاستيراد — أعد تشغيل اللانشر", Toast.LENGTH_LONG).show()
                            } catch (e: Throwable) {
                                Toast.makeText(ctx, "فشل: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                        .setNegativeButton("إلغاء", null).show()
                }
                true
            }
            findPreference<Preference>("reset_layout")?.setOnPreferenceClickListener {
                DesktopStore.resetAll(requireContext()); true
            }
        }
        private fun checkStoragePermission(activity: Activity): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else {
                ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        }

        private fun requestStoragePermission(activity: Activity) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    activity.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        android.net.Uri.parse("package:${activity.packageName}")))
                } catch (_: Throwable) {
                    activity.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            } else {
                ActivityCompat.requestPermissions(activity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1001)
            }
        }

        override fun onDisplayPreferenceDialog(preference: Preference) {
            if (preference is GridSizeDialogPreference) {
                val tag = "GridSizeDialog"
                if (parentFragmentManager.findFragmentByTag(tag) != null) return
                val f = GridSizeDialogFragment.newInstance(preference.key)
                @Suppress("DEPRECATION")
                f.setTargetFragment(this, 0)
                f.show(parentFragmentManager, tag)
            } else {
                super.onDisplayPreferenceDialog(preference)
            }
        }
    }
}