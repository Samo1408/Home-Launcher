package com.homelauncher.prime.ui

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import androidx.preference.PreferenceManager
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import com.homelauncher.prime.R
import com.homelauncher.prime.data.AppItem
import com.homelauncher.prime.util.DesktopStore
import com.homelauncher.prime.util.IntentUtil
import com.homelauncher.prime.util.RootUtil

object AppContextMenu {

    fun show(ctx: Context, anchor: View, app: AppItem, allApps: List<AppItem>,
             onShortcutChanged: () -> Unit, onAppsChanged: () -> Unit,
             onEnterSelectionMode: ((String) -> Unit)? = null, onMove: (() -> Unit)? = null) {

        val inFolder = DesktopStore.appIdToFolder(ctx)[app.id]
        val container = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = buildContextMenuBackground(ctx)
            setPadding(dp(ctx, 10), dp(ctx, 6), dp(ctx, 10), dp(ctx, 6))
        }
        val popup = PopupWindow(container, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); elevation = dp(ctx, 8).toFloat(); isOutsideTouchable = true; isFocusable = true
        }

        fun addItem(emoji: String, onClick: (View) -> Unit) {
            val tv = TextView(ctx).apply {
                text = emoji; setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f); gravity = Gravity.CENTER
                val p = dp(ctx, 10); setPadding(p, p, p, p); isClickable = true; isFocusable = true
                setOnClickListener { v -> v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(60).withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(100).start() }; onClick(v) }
            }
            container.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        addItem("\u2755") { popup.dismiss(); IntentUtil.openAppInfo(ctx, app.packageName, app.user) }
        addItem("\u274C") { popup.dismiss(); confirmUninstall(ctx, listOf(app)) { onAppsChanged() } }
        addItem("\uD83C\uDF0D") { popup.dismiss(); IntentUtil.shareApp(ctx, app.packageName, app.label) }
        addItem("\u2705") { popup.dismiss(); onEnterSelectionMode?.invoke(app.id) }
        addItem("\u267B\uFE0F") {
            popup.dismiss()
            if (DesktopStore.getShortcutIds(ctx).contains(app.id)) DesktopStore.removeShortcut(ctx, app.id) else DesktopStore.addShortcut(ctx, app.id)
            onShortcutChanged()
        }
        if (onMove != null) addItem("\u270B") { popup.dismiss(); onMove.invoke() }
        addItem("\u203C\uFE0F") { v -> showMoreMenu(ctx, v, app, inFolder, onShortcutChanged, onAppsChanged) { popup.dismiss() } }

        container.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        popup.showAsDropDown(anchor, (anchor.width - container.measuredWidth) / 2, -(anchor.height + container.measuredHeight + dp(ctx, 8)))
        try {
            val root = container.rootView; val lp = root.layoutParams as WindowManager.LayoutParams
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_DIM_BEHIND; lp.dimAmount = 0.35f
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(root, lp)
        } catch (_: Throwable) {}
    }

    fun confirmUninstall(ctx: Context, apps: List<AppItem>, onDone: () -> Unit) {
        if (apps.isEmpty()) return
        val names = if (apps.size == 1) "\"${apps[0].label}\"" else apps.joinToString("\n") { "• ${it.label}" }
        AlertDialog.Builder(ctx)
            .setTitle(if (apps.size == 1) ctx.getString(R.string.uninstall_confirm_title) else ctx.getString(R.string.uninstall_confirm_title_multi))
            .setMessage(ctx.getString(R.string.uninstall_confirm_msg, names))
            .setPositiveButton(R.string.uninstall_confirm_yes) { _: DialogInterface, _: Int ->
                for (a in apps) IntentUtil.uninstall(ctx, a.packageName, a.user)
                onDone()
                Toast.makeText(ctx, ctx.resources.getQuantityString(R.plurals.uninstalled_count, apps.size, apps.size), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun showMoreMenu(ctx: Context, anchor: View, app: AppItem, inFolder: String?,
                             onShortcutChanged: () -> Unit, onAppsChanged: () -> Unit, dismissParent: () -> Unit) {
        val items = mutableListOf<Pair<CharSequence, () -> Unit>>()
        items += ctx.getString(R.string.action_view_playstore) to { dismissParent(); IntentUtil.openInPlayStore(ctx, app.packageName) }
        items += ctx.getString(R.string.action_install_other_user) to {
            dismissParent()
            val users = RootUtil.listUsers()
            if (users.isEmpty()) {
                AlertDialog.Builder(ctx).setTitle(R.string.action_install_other_user)
                    .setMessage("تعذر قراءة قائمة المستخدمين. تأكد من وجود صلاحية الروت (su).")
                    .setPositiveButton(android.R.string.ok, null).show()
            } else {
                AlertDialog.Builder(ctx).setTitle(R.string.action_install_other_user)
                    .setItems(users.map { "${it.second}  (id=${it.first})" }.toTypedArray()) { _, which ->
                        val uid = users[which].first
                        AlertDialog.Builder(ctx).setTitle(R.string.action_install_other_user)
                            .setMessage(if (IntentUtil.installToOtherUserAsPlayStore(ctx, app.packageName, uid))
                                "تم تثبيت ${app.label} للمستخدم ${users[which].second} (كمتجر Play)."
                                else "فشل التثبيت (يتطلب root).")
                            .setPositiveButton(android.R.string.ok, null).show()
                    }.setNegativeButton(android.R.string.cancel, null).show()
            }
        }
        items += ctx.getString(R.string.action_open_folder) to { dismissParent(); IntentUtil.openAppDataDir(ctx, app.packageName, app.user) }
        items += ctx.getString(R.string.action_open_app_dir) to { dismissParent(); IntentUtil.openAppInstallDir(ctx, app.packageName, app.user) }
        items += ctx.getString(R.string.action_advanced_perms) to { dismissParent(); IntentUtil.openAdvancedPermissions(ctx, app.packageName) }
        items += ctx.getString(R.string.action_merge_folder) to { dismissParent(); showAddToFolderDialog(ctx, listOf(app.id)) { onShortcutChanged() } }
        items += ctx.getString(R.string.action_uninstall) to { dismissParent(); confirmUninstall(ctx, listOf(app)) { onAppsChanged() } }
        if (inFolder != null) items += ctx.getString(R.string.action_remove_from_folder) to { dismissParent(); DesktopStore.removeAppFromFolder(ctx, inFolder, app.id); onShortcutChanged() }
        showStyledMenu(ctx, anchor, items)
    }

    private fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun buildContextMenuBackground(ctx: Context): GradientDrawable {
        val alpha = (PreferenceManager.getDefaultSharedPreferences(ctx).getInt("context_menu_bg_alpha", 95).coerceIn(0, 100) * 255 / 100).coerceIn(0, 255)
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE; cornerRadius = dp(ctx, 20).toFloat()
            setColor(Color.argb(alpha, 0x20, 0x20, 0x20)); setStroke(dp(ctx, 1), Color.argb(0x33, 0xFF, 0xFF, 0xFF))
        }
    }

    fun showStyledMenu(ctx: Context, anchor: View, items: List<Pair<CharSequence, () -> Unit>>) {
        if (items.isEmpty()) return
        val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; background = buildContextMenuBackground(ctx); setPadding(dp(ctx, 6), dp(ctx, 6), dp(ctx, 6), dp(ctx, 6)) }
        val popup = PopupWindow(container, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); elevation = dp(ctx, 8).toFloat(); isOutsideTouchable = true; isFocusable = true
        }
        items.forEach { (label, action) ->
            val tv = TextView(ctx).apply {
                text = label; setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(ctx, 18), dp(ctx, 12), dp(ctx, 18), dp(ctx, 12)); isClickable = true; isFocusable = true
                setOnClickListener { popup.dismiss(); action() }
            }
            container.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        popup.showAsDropDown(anchor)
    }

    /** Uses IntentUtil.installToOtherUserAsPlayStore for single-app install */
    fun installToOtherUser(ctx: Context, packages: List<String>) {
        if (packages.isEmpty()) return
        val users = RootUtil.listUsers()
        if (users.isEmpty()) { AlertDialog.Builder(ctx).setTitle(R.string.action_install_other_user).setMessage("تعذر قراءة قائمة المستخدمين. تأكد من وجود صلاحية الروت (su).").setPositiveButton(android.R.string.ok, null).show(); return }
        AlertDialog.Builder(ctx).setTitle(R.string.action_install_other_user).setItems(users.map { "${it.second}  (id=${it.first})" }.toTypedArray()) { _, which ->
            val userId = users[which].first
            val results = packages.map { pkg -> IntentUtil.installToOtherUserAsPlayStore(ctx, pkg, userId) }
            val ok = results.all { it }
            AlertDialog.Builder(ctx).setTitle(R.string.action_install_other_user)
                .setMessage(if (ok) "تم تثبيت ${packages.size} تطبيق للمستخدم ${users[which].second} (كمتجر Play)." else "فشل تثبيت بعض التطبيقات (يتطلب root).")
                .setPositiveButton(android.R.string.ok, null).show()
        }.setNegativeButton(android.R.string.cancel, null).show()
    }

    fun showAddToFolderDialog(ctx: Context, appIds: List<String>, onChanged: () -> Unit) {
        if (appIds.isEmpty()) return
        val folders = DesktopStore.getFolders(ctx).keys.toList()
        AlertDialog.Builder(ctx).setTitle(R.string.action_merge_folder).setItems((folders + ctx.getString(R.string.folder_new)).toTypedArray()) { _, which ->
            if (which == folders.size) promptFolderName(ctx) { DesktopStore.addAppsToFolder(ctx, it, appIds); onChanged() }
            else { DesktopStore.addAppsToFolder(ctx, folders[which], appIds); onChanged() }
        }.setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun promptFolderName(ctx: Context, onName: (String) -> Unit) {
        val input = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_TEXT; hint = ctx.getString(R.string.folder_name_hint) }
        AlertDialog.Builder(ctx).setTitle(R.string.folder_new).setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ -> val n = input.text.toString().trim(); if (n.isNotEmpty()) onName(n) }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    fun showFolderMenu(ctx: Context, anchor: View, folderName: String, onChanged: () -> Unit, onMove: (() -> Unit)? = null) {
        val items = mutableListOf<Pair<CharSequence, () -> Unit>>()
        items += ctx.getString(R.string.folder_rename) to {
            val input = EditText(ctx).apply { setText(folderName) }
            AlertDialog.Builder(ctx).setTitle(R.string.folder_rename).setView(input)
                .setPositiveButton(android.R.string.ok) { _, _ -> val n = input.text.toString().trim(); if (n.isNotEmpty()) { DesktopStore.renameFolder(ctx, folderName, n); onChanged() } }
                .setNegativeButton(android.R.string.cancel, null).show()
        }
        items += ctx.getString(R.string.folder_delete) to {
            AlertDialog.Builder(ctx).setTitle(R.string.folder_delete).setMessage(folderName)
                .setPositiveButton(android.R.string.ok) { _, _ -> DesktopStore.deleteFolder(ctx, folderName); onChanged() }
                .setNegativeButton(android.R.string.cancel, null).show()
        }
        if (onMove != null) items += ("✋ تحريك" as CharSequence) to { onMove.invoke() }
        showStyledMenu(ctx, anchor, items)
    }
}
