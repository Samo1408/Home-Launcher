package com.homelauncher.prime.ui

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.TypedValue
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import com.homelauncher.prime.util.DesktopStore

/**
 * Wraps AppWidgetHost lifecycle and renders persisted widgets into a vertical
 * container. Long-pressing a hosted widget opens a menu (resize / remove).
 *
 * The previous implementation used `info.minHeight` directly as a pixel value
 * which on most devices results in tiny / clipped widgets. We now treat the
 * AppWidgetProviderInfo width/height as DP, convert them properly and call
 * `updateAppWidgetSize` so the provider re-measures cleanly.
 */
class WidgetHostManager(
    private val activity: Activity,
    private val container: LinearLayout
) {
    companion object {
        const val HOST_ID = 1024
        const val REQ_PICK = 9101
        const val REQ_CONFIGURE = 9102
        const val REQ_BIND = 9103
    }

    private val host: AppWidgetHost = AppWidgetHost(activity, HOST_ID)
    private val mgr: AppWidgetManager = AppWidgetManager.getInstance(activity)

    fun start() { try { host.startListening() } catch (_: Throwable) {} }
    fun stop() { try { host.stopListening() } catch (_: Throwable) {} }

    fun renderAll() {
        container.removeAllViews()
        for (id in DesktopStore.getWidgetIds(activity)) {
            val info = mgr.getAppWidgetInfo(id) ?: continue
            addHostView(id, info)
        }
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), activity.resources.displayMetrics
    ).toInt()

    private fun pxToDp(px: Int): Int =
        (px / activity.resources.displayMetrics.density).toInt()

    private fun addHostView(widgetId: Int, info: AppWidgetProviderInfo) {
        val hv: AppWidgetHostView = host.createView(activity, widgetId, info)
        hv.setAppWidget(widgetId, info)

        val screenW = activity.resources.displayMetrics.widthPixels
        // Available width inside container: subtract container's horizontal padding.
        val availableW = screenW - container.paddingLeft - container.paddingRight
        // info.minHeight values are returned in pixels by the framework.
        val minHpx = info.minHeight.coerceAtLeast(dp(80))
        // Default height: respect minHeight; clamp so giant widgets don't take the whole screen.
        val defaultHpx = minHpx.coerceAtMost(dp(220))

        // Custom FrameLayout that intercepts a long-press over the widget so
        // the user can always remove/resize it, even if the widget itself
        // consumes touch events.
        lateinit var wrapRef: FrameLayout
        val wrap = object : FrameLayout(activity) {
            private var longPressFired = false
            private val gd = GestureDetector(activity, object : GestureDetector.SimpleOnGestureListener() {
                override fun onLongPress(e: MotionEvent) {
                    longPressFired = true
                    showWidgetMenu(wrapRef, widgetId, info)
                }
            })
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                if (ev.actionMasked == MotionEvent.ACTION_DOWN) longPressFired = false
                gd.onTouchEvent(ev)
                if (longPressFired) {
                    val cancel = MotionEvent.obtain(ev)
                    cancel.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(cancel)
                    cancel.recycle()
                    return true
                }
                return super.dispatchTouchEvent(ev)
            }
        }
        wrapRef = wrap
        wrap.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, defaultHpx
        ).apply { topMargin = dp(6); bottomMargin = dp(6) }
        wrap.addView(
            hv,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        // Tell the provider what space we actually gave it (in dp).
        try {
            val wDp = pxToDp(availableW)
            val hDp = pxToDp(defaultHpx)
            hv.updateAppWidgetSize(Bundle(), wDp, hDp, wDp, hDp)
        } catch (_: Throwable) {}

        container.addView(wrap)
    }

    private fun showWidgetMenu(wrap: FrameLayout, widgetId: Int, info: AppWidgetProviderInfo) {
        val hv = (wrap.getChildAt(0) as? AppWidgetHostView) ?: return
        val pm = PopupMenu(activity, wrap)
        val canResize =
            (info.resizeMode and AppWidgetProviderInfo.RESIZE_VERTICAL) != 0 ||
            (info.resizeMode and AppWidgetProviderInfo.RESIZE_HORIZONTAL) != 0
        if (canResize) pm.menu.add(0, 1, 0, "تكبير")
        if (canResize) pm.menu.add(0, 2, 1, "تصغير")
        pm.menu.add(0, 3, 2, "إزالة الويدجيت")
        pm.setOnMenuItemClickListener { mi ->
            when (mi.itemId) {
                1 -> resize(wrap, hv, +dp(40))
                2 -> resize(wrap, hv, -dp(40))
                3 -> {
                    try { host.deleteAppWidgetId(widgetId) } catch (_: Throwable) {}
                    DesktopStore.removeWidget(activity, widgetId)
                    renderAll()
                }
            }
            true
        }
        pm.show()
    }

    private fun resize(wrap: FrameLayout, hv: AppWidgetHostView, deltaPx: Int) {
        val lp = wrap.layoutParams
        val newH = (lp.height + deltaPx).coerceAtLeast(dp(60)).coerceAtMost(dp(600))
        lp.height = newH
        wrap.layoutParams = lp
        try {
            val wDp = pxToDp(wrap.width.takeIf { it > 0 } ?: activity.resources.displayMetrics.widthPixels)
            val hDp = pxToDp(newH)
            hv.updateAppWidgetSize(Bundle(), wDp, hDp, wDp, hDp)
        } catch (_: Throwable) {}
    }

    /** Launch the system widget picker. */
    fun pickWidget() {
        val newId = host.allocateAppWidgetId()
        val pick = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, newId)
            // These two extras MUST be present (even if empty) — many devices
            // crash the picker when they're missing.
            putParcelableArrayListExtra(AppWidgetManager.EXTRA_CUSTOM_INFO, arrayListOf<android.os.Parcelable>())
            putParcelableArrayListExtra(AppWidgetManager.EXTRA_CUSTOM_EXTRAS, arrayListOf<android.os.Parcelable>())
        }
        try {
            activity.startActivityForResult(pick, REQ_PICK)
        } catch (t: Throwable) {
            host.deleteAppWidgetId(newId)
            Toast.makeText(activity, "لا يوجد منتقي للويدجيت على هذا الجهاز", Toast.LENGTH_SHORT).show()
        }
    }

    /** Returns true if the result was handled. */
    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1) ?: -1
        when (requestCode) {
            REQ_PICK -> {
                if (resultCode == Activity.RESULT_OK && id != -1) bindThenConfigure(id)
                else if (id != -1) host.deleteAppWidgetId(id)
                return true
            }
            REQ_BIND -> {
                if (resultCode == Activity.RESULT_OK && id != -1) configureOrFinalize(id)
                else if (id != -1) host.deleteAppWidgetId(id)
                return true
            }
            REQ_CONFIGURE -> {
                if (resultCode == Activity.RESULT_OK && id != -1) finalizeWidget(id)
                else if (id != -1) host.deleteAppWidgetId(id)
                return true
            }
        }
        return false
    }

    /**
     * After the picker returns, the widget id is allocated but not necessarily
     * bound to a provider on modern Android. We must request BIND_APPWIDGET
     * permission from the user (system dialog) before we can use the widget.
     */
    private fun bindThenConfigure(widgetId: Int) {
        val info = mgr.getAppWidgetInfo(widgetId)
        // Picker normally returns COMPONENT extra in `data` only on some OEMs;
        // when info is non-null the bind already succeeded.
        if (info != null) {
            configureOrFinalize(widgetId)
            return
        }
        // Fall back to user-level bind permission flow.
        val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
        }
        try {
            activity.startActivityForResult(intent, REQ_BIND)
        } catch (_: Throwable) {
            host.deleteAppWidgetId(widgetId)
            Toast.makeText(activity, "تعذر تثبيت الويدجيت", Toast.LENGTH_SHORT).show()
        }
    }

    private fun configureOrFinalize(widgetId: Int) {
        val info = mgr.getAppWidgetInfo(widgetId)
        if (info == null) {
            host.deleteAppWidgetId(widgetId)
            Toast.makeText(activity, "تعذر قراءة معلومات الويدجيت", Toast.LENGTH_SHORT).show()
            return
        }
        if (info.configure != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    host.startAppWidgetConfigureActivityForResult(
                        activity, widgetId, 0, REQ_CONFIGURE, null
                    )
                } else {
                    val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply {
                        component = info.configure
                        putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                    }
                    activity.startActivityForResult(intent, REQ_CONFIGURE)
                }
            } catch (_: Throwable) {
                finalizeWidget(widgetId)
            }
        } else {
            finalizeWidget(widgetId)
        }
    }

    private fun finalizeWidget(widgetId: Int) {
        DesktopStore.addWidget(activity, widgetId)
        renderAll()
    }
}
