package com.homelauncher.prime.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Process
import android.os.UserHandle
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import com.homelauncher.prime.R
import com.homelauncher.prime.admin.LockAdminReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object IntentUtil {

    /** Best-effort: extract userId from a UserHandle via reflection. Falls back to current user. */
    fun userIdOf(user: UserHandle?): Int {
        val uh = user ?: Process.myUserHandle()
        return try {
            UserHandle::class.java.getMethod("getIdentifier").invoke(uh) as Int
        } catch (_: Throwable) {
            // Fallback: parse "UserHandle{N}"
            val s = uh.toString()
            Regex("""\{(\d+)\}""").find(s)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        }
    }

    private fun myUserId(): Int = userIdOf(Process.myUserHandle())

    /** Returns /sdcard/HomeLauncher/ directory (creates if needed) */
    fun homeLauncherDir(): File {
        val dir = File(android.os.Environment.getExternalStorageDirectory(), "HomeLauncher")
        dir.mkdirs()
        return dir
    }

    /** Returns /sdcard/HomeLauncher/APKs/ directory (creates if needed) */
    fun apkCollectionDir(): File {
        val dir = File(homeLauncherDir(), "APKs")
        dir.mkdirs()
        return dir
    }

    fun openAppInfo(ctx: Context, pkg: String, user: UserHandle? = null) {
        val uid = userIdOf(user)
        if (uid != myUserId()) {
            // Launch the settings page inside the target user via root.
            val ok = RootUtil.runAsRoot(
                "am start --user $uid -a android.settings.APPLICATION_DETAILS_SETTINGS -d package:$pkg"
            )
            if (ok) return
            Toast.makeText(ctx, "تعذر فتح معلومات التطبيق للمستخدم $uid (يتطلب root)", Toast.LENGTH_LONG).show()
            return
        }
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$pkg")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(i)
    }

    /** Open the app's page on Google Play Store */
    fun openInPlayStore(ctx: Context, pkg: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Throwable) {
                Toast.makeText(ctx, R.string.playstore_not_found, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val ROOT_BROWSERS = listOf(
        "com.mixplorer",
        "com.mixplorer.silver",
        "bin.mt.plus.canary",
        "bin.mt.plus"
    )

    private fun installedRootBrowsers(ctx: Context): List<String> {
        val pm = ctx.packageManager
        return ROOT_BROWSERS.filter {
            runCatching { pm.getPackageInfo(it, 0); true }.getOrDefault(false)
        }
    }

    private fun launchBrowserAt(ctx: Context, browserPkg: String, path: String): Boolean {
        // Bypass FileUriExposedException on Android 7+ so file:// URIs work
        // when handing folder paths to root-aware file managers.
        try {
            val builder = android.os.StrictMode.VmPolicy.Builder()
            android.os.StrictMode.setVmPolicy(builder.build())
        } catch (_: Throwable) {}

        val uri = Uri.parse("file://$path")
        val mimes = listOf(
            "resource/folder",
            "vnd.android.document/directory",
            "inode/directory",
            "*/*",
            null
        )
        for (mime in mimes) {
            try {
                val i = Intent(Intent.ACTION_VIEW).apply {
                    if (mime == null) data = uri else setDataAndType(uri, mime)
                    setPackage(browserPkg)
                    addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                }
                ctx.startActivity(i); return true
            } catch (_: Throwable) { /* try next mime */ }
        }
        // Last resort: launch the browser without a target so the user can navigate manually
        try {
            val launch = ctx.packageManager.getLaunchIntentForPackage(browserPkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(launch)
                Toast.makeText(ctx, path, Toast.LENGTH_LONG).show()
                return true
            }
        } catch (_: Throwable) {}
        return false
    }


    /** Install an existing app to another user, marking it as installed by Play Store */
    fun installToOtherUserAsPlayStore(ctx: Context, pkg: String, userId: Int): Boolean {
        // Get the APK path first
        val pathOut = RootUtil.runAsRootCapture("pm path $pkg")
        val apkLine = pathOut?.lineSequence()
            ?.map { it.trim() }
            ?.firstOrNull { it.startsWith("package:") }
        val apkPath = apkLine?.removePrefix("package:")?.trim()
        return if (!apkPath.isNullOrEmpty()) {
            RootUtil.runAsRoot("pm install -r --user $userId -i com.android.vending \"$apkPath\"")
        } else {
            // Fallback: use install-existing but we can't set installer
            RootUtil.runAsRoot("pm install-existing --user $userId $pkg")
        }
    }
    fun openInRootBrowser(ctx: Context, path: String) {
        val installed = installedRootBrowsers(ctx)
        if (installed.isEmpty()) {
            Toast.makeText(ctx, R.string.no_root_browser, Toast.LENGTH_LONG).show()
            return
        }
        if (installed.size == 1) {
            if (!launchBrowserAt(ctx, installed[0], path)) {
                Toast.makeText(ctx, R.string.no_root_browser, Toast.LENGTH_SHORT).show()
            }
            return
        }
        val pm = ctx.packageManager
        val labels = installed.map {
            runCatching { pm.getApplicationInfo(it, 0).loadLabel(pm).toString() }
                .getOrDefault(it)
        }.toTypedArray()
        android.app.AlertDialog.Builder(ctx)
            .setTitle(R.string.choose_root_browser)
            .setItems(labels) { _, w -> launchBrowserAt(ctx, installed[w], path) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    fun openAppDataDir(ctx: Context, pkg: String, user: UserHandle? = null) {
        val uid = userIdOf(user)
        // /data/user/<uid>/<pkg> works for all users; for user 0 this is equivalent to /data/data/<pkg>.
        openInRootBrowser(ctx, "/data/user/$uid/$pkg")
    }

    fun openAppInstallDir(ctx: Context, pkg: String, user: UserHandle? = null) {
        val uid = userIdOf(user)
        // Try to ask PackageManager via root for the user-specific path first.
        val pathOut = RootUtil.runAsRootCapture("pm path --user $uid $pkg")
        val apkLine = pathOut?.lineSequence()
            ?.map { it.trim() }
            ?.firstOrNull { it.startsWith("package:") }
        val apkPath = apkLine?.removePrefix("package:")?.trim()
        if (!apkPath.isNullOrEmpty()) {
            val parent = java.io.File(apkPath).parent ?: "/data/app"
            openInRootBrowser(ctx, parent); return
        }
        try {
            val ai = ctx.packageManager.getApplicationInfo(pkg, 0)
            val parent = java.io.File(ai.sourceDir).parent ?: "/data/app"
            openInRootBrowser(ctx, parent)
        } catch (_: Throwable) {
            openInRootBrowser(ctx, "/data/app")
        }
    }

    fun uninstall(ctx: Context, pkg: String, user: UserHandle? = null) {
        val uid = userIdOf(user)
        if (uid != myUserId()) {
            // System uninstall UI runs in user 0; bypass via root in the target user.
            val ok = RootUtil.runAsRoot("pm uninstall --user $uid $pkg")
            val msg = if (ok) "تم إلغاء تثبيت $pkg للمستخدم $uid"
                      else "فشل إلغاء التثبيت للمستخدم $uid (يتطلب root)"
            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
            return
        }
        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    fun adminComponent(ctx: Context) = ComponentName(ctx, LockAdminReceiver::class.java)

    /**
     * Share the installed APK(s) for [pkg] via any sharing-capable app.
     * If the app is split (has split APKs), the parts are bundled into a
     * single .apks zip before sharing.
     */
    fun shareApp(ctx: Context, pkg: String, label: String) {
        Toast.makeText(ctx, R.string.share_preparing, Toast.LENGTH_SHORT).show()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val ai = ctx.packageManager.getApplicationInfo(pkg, 0)
                val base: String = ai.sourceDir
                val splits: Array<String>? = ai.splitSourceDirs
                val outDir = apkCollectionDir()

                val safeName = label.replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { pkg }
                val (file, mime) = if (splits.isNullOrEmpty()) {
                    val f = File(outDir, "$safeName.apk")
                    copyFile(File(base), f)
                    f to "application/vnd.android.package-archive"
                } else {
                    val f = File(outDir, "$safeName.apks")
                    ZipOutputStream(FileOutputStream(f)).use { zip ->
                        addToZip(zip, File(base), "base.apk")
                        splits.forEach { sp ->
                            val src = File(sp)
                            addToZip(zip, src, src.name)
                        }
                    }
                    f to "application/zip"
                }

                val uri: Uri = FileProvider.getUriForFile(
                    ctx, "${ctx.packageName}.fileprovider", file
                )
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, label)
                    putExtra(Intent.EXTRA_TEXT, "$label ($pkg)")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(send, ctx.getString(R.string.share_apk_chooser))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                withContext(Dispatchers.Main) { ctx.startActivity(chooser) }
            } catch (_: Throwable) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(ctx, R.string.share_failed, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun copyFile(src: File, dst: File) {
        FileInputStream(src).use { ins ->
            FileOutputStream(dst).use { outs -> ins.copyTo(outs) }
        }
    }

    private fun addToZip(zip: ZipOutputStream, src: File, name: String) {
        zip.putNextEntry(ZipEntry(name))
        FileInputStream(src).use { it.copyTo(zip) }
        zip.closeEntry()
    }

    /**
     * Opens an Advanced Permissions chooser containing the most commonly
     * needed special-access settings screens (usage stats, all-files access,
     * unknown sources, overlay, etc.).
     */
    fun openAdvancedPermissions(ctx: Context, pkg: String) {
        data class Perm(val label: String, val intent: Intent?)

        fun appIntent(action: String): Intent =
            Intent(action, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        fun globalIntent(action: String): Intent =
            Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        val items = mutableListOf<Perm>()
        items += Perm("Usage access (استخدام البيانات)",
            globalIntent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            items += Perm("All files access (الوصول لكل الملفات)",
                appIntent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION))
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            items += Perm("Install unknown apps (مصادر غير معروفة)",
                appIntent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES))
        }
        items += Perm("Display over other apps (الرسم فوق التطبيقات)",
            appIntent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
        items += Perm("Modify system settings (تعديل إعدادات النظام)",
            appIntent(Settings.ACTION_MANAGE_WRITE_SETTINGS))
        items += Perm("Notification access (الوصول للإشعارات)",
            globalIntent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        items += Perm("Accessibility (إمكانية الوصول)",
            globalIntent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            items += Perm("Battery optimization (تجاهل توفير البطارية)",
                globalIntent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            items += Perm("Do Not Disturb access (وضع عدم الإزعاج)",
                globalIntent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            items += Perm("Default apps (التطبيقات الافتراضية)",
                globalIntent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        }
        items += Perm("Device admin apps (مسؤولو الجهاز)",
            globalIntent(Settings.ACTION_SECURITY_SETTINGS))
        items += Perm("App info (إعدادات التطبيق)",
            appIntent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS))

        val labels = items.map { it.label }.toTypedArray()
        android.app.AlertDialog.Builder(ctx)
            .setTitle("Advanced Permissions")
            .setItems(labels) { _, w ->
                try { ctx.startActivity(items[w].intent) }
                catch (_: Throwable) {
                    Toast.makeText(ctx, "هذا الإعداد غير متاح على جهازك", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
